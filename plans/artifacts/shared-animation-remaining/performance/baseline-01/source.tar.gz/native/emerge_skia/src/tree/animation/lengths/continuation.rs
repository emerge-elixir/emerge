//! Proof of a foreign resolved-dimension clock, not a numeric lowering.
use super::*;

pub(super) fn footprint_context_continues(
    tree: &ElementTree,
    old: &Track,
    next: &Projection,
    positions: &[(NodeId, u64, RunRef<'_>, timing::SegmentPosition)],
    now: Instant,
    tracks: &HashMap<(NodeId, Axis), Arc<Track>>,
    boundaries: Option<&HashMap<(NodeId, Axis), Arc<Track>>>,
) -> Option<Arc<ClockContinuation>> {
    if old.projection.nodes.len() != next.nodes.len() {
        return None;
    }
    let witnesses = old
        .projection
        .nodes
        .iter()
        .map(|(id, before)| {
            let after = next.nodes.get(id)?;
            if before == after {
                return Some(Vec::new());
            }
            if before.model != after.model {
                return None;
            }
            positions
                .iter()
                .filter(|(node, _, _, _)| node == id)
                .find_map(|(_, mount, run, p)| {
                    let clock = AnimationRuntimeEntry {
                        spec_hash: run.revision,
                        started_at: run.started,
                    };
                    if run.started > old.evaluated_at {
                        return None;
                    }
                    let previous =
                        timing::position(run.spec, Some(&clock), Some(old.evaluated_at))?;
                    let changed_interval =
                        previous.index != p.index || previous.start_ms != p.start_ms;
                    if changed_interval && boundaries.is_none() {
                        return None;
                    }
                    let endpoints = [previous.index, previous.index + 1]
                        .map(|index| layout_attrs(&run.fields.select(&run.spec.keyframes[index])));
                    let next_endpoints = [p.index, p.index + 1]
                        .map(|index| layout_attrs(&run.fields.select(&run.spec.keyframes[index])));
                    if endpoints.iter().chain(&next_endpoints).any(|attrs| {
                        *attrs
                            != Attrs {
                                width: attrs.width.clone(),
                                height: attrs.height.clone(),
                                ..Default::default()
                            }
                    }) {
                        return None;
                    }
                    let mut a = before.clone();
                    let mut b = before.clone();
                    for (node, time) in [(&mut a, old.evaluated_at), (&mut b, now)] {
                        apply_sample_attrs(
                            &mut node.attrs,
                            &layout_attrs(&run.fields.select(
                                &sample_animation_spec(run.spec, Some(&clock), Some(time)).attrs,
                            )),
                        );
                    }
                    let witnesses = [Axis::Width, Axis::Height]
                        .into_iter()
                        .map(|axis| {
                            let first = length(&endpoints[0], axis);
                            let last = length(&endpoints[1], axis);
                            if first.is_none() && last.is_none() {
                                return Some(None);
                            }
                            let (first, last) = (first?, last?);
                            // Keep the existing conservative pixel-equivalence path separate.
                            if direct_numeric(first, last) && !changed_interval {
                                return None;
                            }
                            let track = tracks.get(&(*id, axis))?;
                            if !track.same_run(*run, *mount)
                                || track.key.segment != previous.index
                                || track.key.cycle != previous.start_ms.to_bits()
                                || track.model != old.model
                                || !Arc::ptr_eq(&track.context, &old.context)
                            {
                                return None;
                            }
                            let next_track = if changed_interval {
                                boundaries?.get(&(*id, axis))?
                            } else {
                                track
                            };
                            if !next_track.same_run(*run, *mount)
                                || next_track.key.segment != p.index
                                || next_track.key.cycle != p.start_ms.to_bits()
                                || next_track.model != old.model
                                || !Arc::ptr_eq(&next_track.context, &old.context)
                                || length(&next_endpoints[0], axis).is_none()
                                || length(&next_endpoints[1], axis).is_none()
                            {
                                return None;
                            }
                            let from = track.sample(*run, previous, old.evaluated_at).ok()?;
                            let to = next_track.sample(*run, *p, now).ok()?;
                            let (before_fp, after_fp) = if axis == Axis::Width {
                                (before.width, after.width)
                            } else {
                                (before.height, after.height)
                            };
                            if before_fp.is_none()
                                && crate::tree::layout::dimensions::capture_axis(tree, id, axis)
                                    .is_none_or(|published| !published.release_matches(from))
                            {
                                return None;
                            }
                            if before_fp.is_some_and(|fp| !fp.release_matches(from))
                                || after_fp.is_some_and(|fp| !fp.release_matches(to))
                            {
                                return None;
                            }
                            if after_fp.is_none() && p.active {
                                return None;
                            }
                            if before_fp.is_some() {
                                clear_length(&mut a.attrs, axis);
                            }
                            if after_fp.is_some() {
                                clear_length(&mut b.attrs, axis);
                            }
                            match axis {
                                Axis::Width => {
                                    a.width = before_fp;
                                    b.width = after_fp;
                                }
                                Axis::Height => {
                                    a.height = before_fp;
                                    b.height = after_fp;
                                }
                            }
                            Some(Some((
                                (*id, axis),
                                before_fp.map(|_| from),
                                if Arc::ptr_eq(track, next_track) {
                                    vec![Arc::clone(track)]
                                } else {
                                    vec![Arc::clone(track), Arc::clone(next_track)]
                                },
                                after_fp.is_none().then_some(to),
                            )))
                        })
                        .collect::<Option<Vec<_>>>()?;

                    (a == *before && b == *after)
                        .then(|| witnesses.into_iter().flatten().collect::<Vec<_>>())
                })
        })
        .collect::<Option<Vec<_>>>()?
        .into_iter()
        .flatten()
        .collect::<Vec<_>>();
    let next_pixels = witnesses
        .iter()
        .filter_map(|(key, _, _, terminal)| terminal.map(|fp| (*key, fp)))
        .collect::<Vec<_>>();
    Some(Arc::new(ClockContinuation {
        independent: None,
        projection: Arc::clone(&old.projection),
        pixels: witnesses
            .iter()
            .filter_map(|(key, fp, ..)| fp.map(|fp| (*key, fp)))
            .collect(),
        next: (!next_pixels.is_empty()).then(|| (Arc::new(next.clone()), next_pixels)),
        foreign: witnesses
            .into_iter()
            .flat_map(|(key, _, tracks, _)| tracks.into_iter().map(move |track| (key, track)))
            .collect(),
    }))
}

/// Retained ancestry only; no future animation dependency graph.
pub(super) fn is_ancestor(tree: &ElementTree, ancestor: NodeId, node: NodeId) -> bool {
    std::iter::successors(tree.ix_of(&node), |ix| {
        #[cfg(any(test, feature = "bench-diagnostics"))]
        {
            let visits = &tree.animation_query_retirement.continuation_ancestry_visits;
            visits.set(visits.get() + 1);
        }
        match tree.parent_link_of(*ix)? {
            crate::tree::element::ParentLink::Child { parent } => Some(parent),
            crate::tree::element::ParentLink::Nearby { host, .. } => Some(host),
        }
    })
    .take(tree.len())
    .skip(1)
    .any(|ix| tree.get_ix(ix).is_some_and(|node| node.id == ancestor))
}

impl ClockContinuation {
    pub(super) fn permits_owner(&self, tree: &ElementTree, owner: NodeId) -> bool {
        // Native evidence can be shared, but mixed-clock eligibility is relative
        // to each consumer. Never cache the first owner's ancestry decision.
        // Raw pixels (or fully witnessed pixel equivalents) do not depend on a
        // resolved foreign destination and can also drive ancestor intrinsic size.
        if let Some((replaced, _)) = &self.independent
            && replaced.iter().any(|id| {
                *id == owner || is_ancestor(tree, *id, owner) || is_ancestor(tree, owner, *id)
            })
        {
            return false;
        }
        self.foreign
            .iter()
            .all(|(driver, _)| is_ancestor(tree, driver.0, owner))
    }
}

/// Cache only verified-common input classifications. Each caller recomputes its
/// replacement set and checks causal ancestry; one owner's eligibility cannot leak.
#[derive(Default)]
pub(super) struct IndependenceCache {
    proofs: HashMap<IndependenceKey, Option<Arc<ClockContinuation>>>,
}
type IndependenceKey = (usize, usize, Instant, bool, Vec<NodeId>);

impl IndependenceCache {
    /// Candidate only: native original and hybrid targets must both be verified.
    /// Siblings are not assumed independent just because they lack an ancestry edge.
    pub(super) fn continuation(
        &mut self,
        tree: &ElementTree,
        (owner, old, releasing): (NodeId, &Track, &HashSet<(NodeId, Axis)>),
        next: &Arc<Projection>,
        (positions, now): (
            &[(NodeId, u64, RunRef<'_>, timing::SegmentPosition)],
            Instant,
        ),
        tracks: &HashMap<(NodeId, Axis), Arc<Track>>,
        boundaries: Option<&HashMap<(NodeId, Axis), Arc<Track>>>,
    ) -> Option<Arc<ClockContinuation>> {
        if old.projection.nodes.len() != next.nodes.len() {
            return None;
        }
        let releases = |node| {
            releasing.contains(&(node, Axis::Width)) || releasing.contains(&(node, Axis::Height))
        };
        let consumer_releases = releases(owner);
        let mut replaced = old
            .projection
            .nodes
            .iter()
            .filter_map(|(id, before)| {
                let after = next.nodes.get(id)?;
                if before == after || before.model != after.model || *id == owner {
                    return None;
                }
                // Co-releasing owners belong to the joint target contract, not
                // external context that a releasing consumer may replace.
                let co_releasing = consumer_releases && releases(*id);
                (!co_releasing && !is_ancestor(tree, *id, owner) && !is_ancestor(tree, owner, *id))
                    .then_some(*id)
            })
            .collect::<Vec<_>>();
        if replaced.is_empty() {
            return None;
        }
        replaced.sort_unstable_by_key(|id| id.0);
        let key = (
            Arc::as_ptr(&old.projection) as usize,
            Arc::as_ptr(next) as usize,
            old.evaluated_at,
            boundaries.is_some(),
            replaced.clone(),
        );
        self.proofs
            .entry(key)
            .or_insert_with(|| {
                let mut projection = (*old.projection).clone();
                projection
                    .nodes
                    .extend(replaced.iter().map(|id| (*id, next.nodes[id].clone())));
                let candidate = Track {
                    projection: Arc::new(projection),
                    ..old.clone()
                };
                let proof = numeric_context_continues(
                    tree,
                    &candidate,
                    next,
                    positions,
                    now,
                    boundaries.is_some(),
                    tracks,
                )
                .or_else(|| {
                    footprint_context_continues(
                        tree, &candidate, next, positions, now, tracks, boundaries,
                    )
                })?;
                Some(Arc::new(ClockContinuation {
                    independent: Some((replaced, Arc::clone(&old.projection))),
                    ..(*proof).clone()
                }))
            })
            .as_ref()
            .filter(|proof| proof.permits_owner(tree, owner))
            .cloned()
    }
}
