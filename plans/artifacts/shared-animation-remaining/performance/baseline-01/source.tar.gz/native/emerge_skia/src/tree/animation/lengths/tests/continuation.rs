use super::support::{AttemptError, Driver, Event, Injection, Mode};
use super::*;
use crate::tree::animation::lengths::inspection::QueryKind;
use crate::tree::animation::timing::apply_curve;

fn late_pixel_parent(axis: Axis) -> ElementTree {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
    let mut parent = spec(Length::Fill, Length::Px(400.0), 2000.0, axis);
    parent.keyframes.push(
        spec(Length::Px(800.0), Length::Px(800.0), 1.0, axis)
            .keyframes
            .remove(0),
    );
    tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(parent);
    let child = tree
        .get_mut(&id(2))
        .unwrap()
        .spec
        .declared
        .animate
        .as_mut()
        .unwrap();
    child.duration_ms = 2000.0;
    child.keyframes.insert(0, child.keyframes[0].clone());
    tree
}

#[test]
fn later_pixel_segments_preserve_dependent_curve_anchors_through_joint_completion() {
    for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
        for axis in [Axis::Width, Axis::Height] {
            let mut d = Driver::new(late_pixel_parent(axis), Instant::now(), mode);
            for (us, parent, child) in [
                (0, 600.0, 40.0),
                (500_000, 500.0, 40.0),
                (1_000_000, 400.0, 40.0),
                (1_500_000, 600.0, 170.0),
                (2_000_000, 800.0, 400.0),
            ] {
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                close(extent(&d.tree, 1, axis), parent);
                close(extent(&d.tree, 2, axis), child);
            }
            assert!(d.runtime.groups.is_empty());
            assert!(d.tree.length_runtime.is_none());
        }
    }
}

#[test]
fn later_pixel_segments_follow_all_curves_rates_and_scales() {
    for axis in [Axis::Width, Axis::Height] {
        for scale in [0.5, 1.0, 2.0] {
            for curve in [
                AnimationCurve::Linear,
                AnimationCurve::EaseIn,
                AnimationCurve::EaseOut,
                AnimationCurve::EaseInOut,
            ] {
                for hz in [30, 60, 120] {
                    let mut tree = late_pixel_parent(axis);
                    tree.get_mut(&id(2))
                        .unwrap()
                        .spec
                        .declared
                        .animate
                        .as_mut()
                        .unwrap()
                        .curve = curve.clone();
                    let mut d = Driver::new(tree, Instant::now(), Mode::Active);
                    assert!(
                        d.step(
                            0,
                            vec![Event::Viewport {
                                width: 600.0,
                                height: 600.0,
                                scale
                            }]
                        )
                        .result
                        .is_ok()
                    );
                    for frame in 1..=hz * 2 {
                        let us = frame * 1_000_000 / hz;
                        let out = d.step(us, vec![]);
                        assert!(out.result.is_ok(), "{:?}", out.result);
                        if let Some(state) = d.tree.length_runtime.as_ref() {
                            assert_eq!(state.resolver.stats().model_copies, 1);
                        }
                        let t = (us as f64 / 1_000_000.0 - 1.0).max(0.0);
                        let expected = 40.0 + (200.0 + 200.0 * t - 40.0) * apply_curve(&curve, t);
                        close(
                            capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                            expected as f32,
                        );
                        assert!(
                            out.inspection.queries.len() <= 4,
                            "{:?}",
                            out.inspection.queries
                        );
                    }
                    assert!(d.tree.length_runtime.is_none());
                }
            }
        }
    }
}

#[test]
fn pixel_continuation_witness_and_output_failures_preserve_publication_and_retry_clocks() {
    for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
        for axis in [Axis::Width, Axis::Height] {
            for failure in [
                Injection::Query(QueryKind::PriorTarget),
                Injection::Query(QueryKind::PixelContinuation),
                Injection::BeforeLayout,
            ] {
                let mut d = Driver::new(late_pixel_parent(axis), Instant::now(), mode);
                d.step(0, vec![]);
                let before = d.step(1_000_000, vec![]).published_after.unwrap();
                let failed = d.attempt(1_500_000, vec![], failure);
                assert_eq!(
                    failed.result,
                    Err(if failure == Injection::BeforeLayout {
                        AttemptError::BeforeLayout
                    } else {
                        AttemptError::Native(ProjectionError::InjectedQuery)
                    })
                );
                failed.published_after.unwrap().assert_same(&before);
                let out = d.step(1_750_000, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                close(extent(&d.tree, 2, axis), 272.5);
                assert!(d.step(2_000_000, vec![]).result.is_ok());
                assert!(d.tree.length_runtime.is_none());
            }
        }
    }
}

#[test]
fn pixel_continuation_cannot_launder_corrupted_dependent_terminal_footprints() {
    for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
        for axis in [Axis::Width, Axis::Height] {
            for policy in [false, true] {
                let mut d = Driver::new(late_pixel_parent(axis), Instant::now(), mode);
                d.step(0, vec![]);
                let before = d.step(1_000_000, vec![]).published_after.unwrap();
                let track = Arc::make_mut(
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .get_mut(&(id(2), axis))
                        .unwrap(),
                );
                if policy {
                    track.to.policy.fill_request *= 0.5;
                } else {
                    track.to.charge -= 20.0;
                }
                let out = d.step(1_500_000, vec![]);
                assert_eq!(
                    out.result,
                    Err(AttemptError::Native(ProjectionError::ReleaseMismatch(
                        id(2),
                        axis
                    )))
                );
                out.published_after.unwrap().assert_same(&before);
            }
        }
    }
}

#[test]
fn pixel_equivalence_checks_foreign_policy_in_native_layout_before_and_after_the_frame() {
    for axis in [Axis::Width, Axis::Height] {
        for prior_sample in [false, true] {
            let mut d = Driver::new(late_pixel_parent(axis), Instant::now(), Mode::Full);
            d.step(0, vec![]);
            let first = d.step(1_000_000, vec![]).published_after.unwrap();
            let before = if prior_sample {
                d.step(1_500_000, vec![]).published_after.unwrap()
            } else {
                first
            };
            let state = d.tree.length_runtime.as_mut().unwrap();
            let parent = Arc::make_mut(state.tracks.get_mut(&(id(1), axis)).unwrap());
            parent.from.policy.children_fill = 0.0;
            parent.to.policy.children_fill = 0.0;
            if prior_sample {
                let child = Arc::make_mut(state.tracks.get_mut(&(id(2), axis)).unwrap());
                let projection = Arc::make_mut(&mut child.projection);
                let parent = projection.nodes.get_mut(&id(1)).unwrap();
                let sample = if axis == Axis::Width {
                    parent.width.as_mut()
                } else {
                    parent.height.as_mut()
                }
                .unwrap();
                sample.policy.children_fill = 0.0;
            }
            let out = d.step(1_750_000, vec![]);
            assert_eq!(
                out.result,
                Err(AttemptError::Native(ProjectionError::ReleaseMismatch(
                    id(if prior_sample { 1 } else { 2 }),
                    axis
                )))
            );
            assert!(out.inspection.queries.iter().any(|q| q.kind
                == if prior_sample {
                    QueryKind::PriorTarget
                } else {
                    QueryKind::PixelContinuation
                }));
            out.published_after.unwrap().assert_same(&before);
        }
    }
}

#[test]
fn later_pixel_segments_preserve_parent_scoped_charges_with_local_scale() {
    for axis in [Axis::Width, Axis::Height] {
        for scale in [0.5, 1.0, 2.0] {
            let mut tree = late_pixel_parent(axis);
            tree.get_mut(&id(1)).unwrap().spec.declared.layout_scale = Some(scale);
            tree.insert(Element::with_attrs(
                id(4),
                if axis == Axis::Width {
                    ElementKind::Row
                } else {
                    ElementKind::Column
                },
                vec![],
                Attrs {
                    width: Some(Length::Px(600.0)),
                    height: Some(Length::Px(600.0)),
                    ..Default::default()
                },
            ));
            tree.set_children(&id(4), vec![id(1)]).unwrap();
            tree.set_root_id(id(4));
            let mut d = Driver::new(tree, Instant::now(), Mode::Dirty);
            for (us, expected) in [
                (0, None),
                (1_000_000, Some(40.0)),
                (1_500_000, Some(170.0)),
                (1_750_000, Some(272.5)),
                (2_000_000, Some(400.0)),
            ] {
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                if let Some(expected) = expected {
                    close(
                        capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                        expected,
                    );
                }
            }
            assert!(d.tree.length_runtime.is_none());
        }
    }
}

#[test]
fn pixel_segment_continuations_reset_across_skipped_cycles_without_replaying_them() {
    for axis in [Axis::Width, Axis::Height] {
        for repeat in [AnimationRepeat::Times(2000), AnimationRepeat::Loop] {
            let mut tree = late_pixel_parent(axis);
            for node in [1, 2] {
                tree.get_mut(&id(node))
                    .unwrap()
                    .spec
                    .declared
                    .animate
                    .as_mut()
                    .unwrap()
                    .repeat = repeat.clone();
            }
            let mut d = Driver::new(tree, Instant::now(), Mode::Active);
            for (us, expected) in [
                (0, 40.0),
                (1_000_000, 40.0),
                (1_500_000, 170.0),
                (2_001_500_000, 170.0),
                (2_001_750_000, 272.5),
            ] {
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                close(
                    capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                    expected,
                );
                assert!(out.inspection.queries.len() <= 4);
            }
            if !matches!(repeat, AnimationRepeat::Loop) {
                let out = d.step(4_000_000_000, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 400.0);
                assert!(d.runtime.groups.is_empty());
                assert!(d.tree.length_runtime.is_none());
                assert!(out.inspection.queries.len() <= 4);
            }
        }
    }
}

#[test]
fn mixed_parent_clocks_preserve_dependent_anchors_and_native_release() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for reverse in [false, true] {
                let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
                tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(spec(
                    if reverse {
                        Length::Fill
                    } else {
                        Length::Px(200.0)
                    },
                    if reverse {
                        Length::Px(200.0)
                    } else {
                        Length::Fill
                    },
                    2000.0,
                    axis,
                ));
                tree.get_mut(&id(1))
                    .unwrap()
                    .spec
                    .declared
                    .animate
                    .as_mut()
                    .unwrap()
                    .repeat = AnimationRepeat::Loop;
                let mut d = Driver::new(tree, Instant::now(), mode);
                for (us, expected) in [
                    (0, 40.0),
                    (500_000, if reverse { 145.0 } else { 95.0 }),
                    (1_000_000, 200.0),
                    (1_750_000, if reverse { 125.0 } else { 275.0 }),
                ] {
                    let out = d.step(us, vec![]);
                    assert!(
                        out.result.is_ok(),
                        "{us}: {:?} {:?}",
                        out.result,
                        out.inspection.queries
                    );
                    close(
                        capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                        expected,
                    );
                }
                assert!(d.tree.length_runtime.is_some());
                assert!(d.runtime.groups.is_empty());
            }
        }
    }
}

#[test]
fn mixed_ancestor_footprints_follow_curves_and_all_frame_rates_at_each_scale() {
    for axis in [Axis::Width, Axis::Height] {
        for scale in [0.5, 1.0, 2.0] {
            for curve in [
                AnimationCurve::Linear,
                AnimationCurve::EaseIn,
                AnimationCurve::EaseOut,
                AnimationCurve::EaseInOut,
            ] {
                for hz in [30, 60, 120] {
                    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
                    let mut parent = spec(Length::Px(200.0), Length::Fill, 2000.0, axis);
                    parent.curve = curve.clone();
                    parent.repeat = AnimationRepeat::Loop;
                    tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(parent);
                    tree.get_mut(&id(2))
                        .unwrap()
                        .spec
                        .declared
                        .animate
                        .as_mut()
                        .unwrap()
                        .curve = curve.clone();
                    let mut d = Driver::new(tree, Instant::now(), Mode::Active);
                    assert!(
                        d.step(
                            0,
                            vec![Event::Viewport {
                                width: 600.0 * scale,
                                height: 600.0 * scale,
                                scale
                            }]
                        )
                        .result
                        .is_ok()
                    );
                    for frame in 1..hz * 2 {
                        let us = frame * 1_000_000 / hz;
                        let t = us as f64 / 1_000_000.0;
                        let out = d.step(us, vec![]);
                        assert!(out.result.is_ok(), "{us}: {:?}", out.result);
                        let parent = 200.0 + 400.0 * apply_curve(&curve, t / 2.0);
                        let child = if t <= 1.0 {
                            40.0 + (parent / 2.0 - 40.0) * apply_curve(&curve, t)
                        } else {
                            parent / 2.0
                        };
                        close(
                            capture_axis(&d.tree, &id(1), axis).unwrap().visible,
                            parent as f32,
                        );
                        close(
                            capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                            child as f32,
                        );
                        assert!(out.inspection.queries.len() <= 4);
                    }
                    assert!(d.tree.length_runtime.is_some());
                    assert!(d.runtime.groups.is_empty());
                }
            }
        }
    }
}

#[test]
fn mixed_ancestor_witnesses_validate_foreign_goals_and_keep_failed_output_retry_safe() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for failure in 0..4 {
                let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
                tree.get_mut(&id(1)).unwrap().spec.declared.animate =
                    Some(spec(Length::Px(200.0), Length::Fill, 2000.0, axis));
                tree.get_mut(&id(1))
                    .unwrap()
                    .spec
                    .declared
                    .animate
                    .as_mut()
                    .unwrap()
                    .repeat = AnimationRepeat::Loop;
                let mut d = Driver::new(tree, Instant::now(), mode);
                let before = d.step(0, vec![]).published_after.unwrap();
                let old = d.tree.length_runtime.as_ref().unwrap().tracks[&(id(1), axis)].clone();
                if failure < 2 {
                    let track = Arc::make_mut(
                        d.tree
                            .length_runtime
                            .as_mut()
                            .unwrap()
                            .tracks
                            .get_mut(&(id(1), axis))
                            .unwrap(),
                    );
                    if failure == 0 {
                        track.to.intrinsic += 20.0;
                    } else {
                        track.to.policy.fill_request *= 0.5;
                    }
                }
                let injection = match failure {
                    2 => Injection::Query(QueryKind::ForeignTarget),
                    3 => Injection::BeforeLayout,
                    _ => Injection::None,
                };
                let out = d.attempt(500_000, vec![], injection);
                let expected = match failure {
                    2 => AttemptError::Native(ProjectionError::InjectedQuery),
                    3 => AttemptError::BeforeLayout,
                    _ => AttemptError::Native(ProjectionError::ReleaseMismatch(id(1), axis)),
                };
                assert_eq!(out.result, Err(expected));
                out.published_after.unwrap().assert_same(&before);
                // Restore only test corruption, not a live model/viewport rollback.
                if failure < 2 {
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .insert((id(1), axis), old);
                }
                let out = d.step(750_000, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 141.25);
                assert!(d.step(1_000_000, vec![]).result.is_ok());
                assert!(d.step(2_000_000, vec![]).result.is_ok());
                assert!(d.tree.length_runtime.is_some());
                assert!(d.runtime.groups.is_empty());
            }
        }
    }
}

#[test]
fn finite_fill_parents_share_full_intrinsic_destinations_with_children() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for child_duration in [1000.0, 2000.0] {
                let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
                tree.get_mut(&id(1)).unwrap().spec.declared.animate =
                    Some(spec(Length::Px(200.0), Length::Fill, 2000.0, axis));
                tree.get_mut(&id(2))
                    .unwrap()
                    .spec
                    .declared
                    .animate
                    .as_mut()
                    .unwrap()
                    .duration_ms = child_duration;
                let mut d = Driver::new(tree, Instant::now(), mode);
                for us in [0, 500_000, 1_000_000, 1_500_000, 2_000_000] {
                    let out = d.step(us, vec![]);
                    assert!(out.result.is_ok(), "{us}: {:?}", out.result);
                    let t = us as f32 / 2_000_000.0;
                    let parent = capture_axis(&d.tree, &id(1), axis).unwrap();
                    close(parent.visible, 200.0 + 400.0 * t);
                    close(parent.intrinsic, 200.0 * (1.0 - t));
                    close(
                        capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                        40.0 + 260.0 * (us as f32 / (child_duration as f32 * 1000.0)).min(1.0),
                    );
                }
                assert!(d.runtime.groups.is_empty());
                assert!(d.tree.length_runtime.is_none());
            }
        }
    }
}

#[test]
fn intrinsic_group_links_cross_static_fill_wrappers_but_not_fixed_axis_boundaries() {
    for axis in [Axis::Width, Axis::Height] {
        for fixed in [false, true] {
            let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
            tree.get_mut(&id(1)).unwrap().spec.declared.animate =
                Some(spec(Length::Px(200.0), Length::Fill, 2000.0, axis));
            let mut attrs = Attrs {
                width: Some(Length::Fill),
                height: Some(Length::Fill),
                ..Default::default()
            };
            if fixed {
                if axis == Axis::Width {
                    attrs.width = Some(Length::Px(100.0));
                } else {
                    attrs.height = Some(Length::Px(100.0));
                }
            }
            tree.insert(Element::with_attrs(
                id(4),
                if axis == Axis::Width {
                    ElementKind::Row
                } else {
                    ElementKind::Column
                },
                vec![],
                attrs,
            ));
            tree.set_children(&id(1), vec![id(4)]).unwrap();
            tree.set_children(&id(4), vec![id(2), id(3)]).unwrap();
            let mut d = Driver::new(tree, Instant::now(), Mode::Dirty);
            for (us, t) in [(0, 0.0), (500_000, 0.5), (1_000_000, 1.0), (2_000_000, 1.0)] {
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{us}: {:?}", out.result);
                close(
                    capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                    40.0 + (if fixed { 10.0 } else { 260.0 }) * t,
                );
            }
            assert!(d.tree.length_runtime.is_none());
        }
    }
}

#[test]
fn shared_clock_evidence_checks_each_consumers_dependency_direction() {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, Axis::Width);
    tree.insert(Element::with_attrs(
        id(4),
        ElementKind::El,
        vec![],
        Attrs::default(),
    ));
    tree.set_children(&id(2), vec![id(4)]).unwrap();
    let mut d = Driver::new(tree, Instant::now(), Mode::Full);
    assert!(d.step(0, vec![]).result.is_ok());
    let track = Arc::clone(&d.tree.length_runtime.as_ref().unwrap().tracks[&(id(2), Axis::Width)]);
    for mixed in [false, true] {
        for independent in [false, true] {
            let proof = Arc::new(ClockContinuation {
                independent: independent.then(|| (vec![id(3)], Arc::clone(&track.projection))),
                projection: Arc::clone(&track.projection),
                pixels: vec![],
                next: None,
                foreign: if mixed {
                    vec![((id(2), Axis::Width), Arc::clone(&track))]
                } else {
                    vec![]
                },
            });
            for owners in [[1, 2, 3, 4], [4, 3, 2, 1], [3, 1, 4, 2]] {
                for owner in owners {
                    // A mixed-clock cache hit from child 4 cannot authorize upward
                    // feedback in owner 1, nor can rejection suppress child 4's proof.
                    let cached = Arc::clone(&proof);
                    assert_eq!(
                        cached.permits_owner(&d.tree, id(owner)),
                        (!mixed || owner == 4) && (!independent || [2, 4].contains(&owner))
                    );
                }
            }
        }
    }
}

fn pixel_wrapper_tree(axis: Axis) -> ElementTree {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
    tree.get_mut(&id(1)).unwrap().spec.declared.animate =
        Some(spec(Length::Px(200.0), Length::Fill, 1000.0, axis));
    tree.get_mut(&id(2))
        .unwrap()
        .spec
        .declared
        .animate
        .as_mut()
        .unwrap()
        .duration_ms = 2000.0;
    let mut motion = spec(Length::Px(200.0), Length::Px(400.0), 4000.0, axis);
    motion.repeat = AnimationRepeat::Loop;
    tree.insert(Element::with_attrs(
        id(4),
        if axis == Axis::Width {
            ElementKind::Row
        } else {
            ElementKind::Column
        },
        vec![],
        Attrs {
            width: Some(Length::Fill),
            height: Some(Length::Fill),
            animate: Some(motion),
            ..Default::default()
        },
    ));
    tree.set_children(&id(1), vec![id(4)]).unwrap();
    tree.set_children(&id(4), vec![id(2), id(3)]).unwrap();
    tree
}

#[test]
fn looping_pixel_wrappers_drive_both_ancestor_and_descendant_group_members() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut d = Driver::new(pixel_wrapper_tree(axis), Instant::now(), mode);
            for us in [0, 500_000, 1_000_000, 1_500_000, 2_000_000] {
                let out = d.step(us, vec![]);
                assert!(
                    out.result.is_ok(),
                    "{axis:?} {mode:?} {us}: {:?}",
                    out.result
                );
                let t = us as f32 / 1_000_000.0;
                close(
                    capture_axis(&d.tree, &id(1), axis).unwrap().visible,
                    200.0 + 400.0 * t.min(1.0),
                );
                close(
                    capture_axis(&d.tree, &id(4), axis).unwrap().visible,
                    200.0 + 50.0 * t,
                );
                close(
                    capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                    40.0 + (100.0 + 25.0 * t - 40.0) * t / 2.0,
                );
                assert!(out.inspection.queries.len() <= 3);
            }
            close(
                capture_axis(&d.tree, &id(1), axis).unwrap().intrinsic,
                300.0,
            );
            assert!(d.runtime.groups.is_empty());
            assert!(d.tree.length_runtime.is_none());
        }
    }
}

#[test]
fn pixel_wrapper_release_proofs_keep_intrinsic_corruption_checks_and_retry_clocks() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for failure in 0..3 {
                let mut d = Driver::new(pixel_wrapper_tree(axis), Instant::now(), mode);
                for us in [0, 500_000, 1_000_000, 1_500_000] {
                    assert!(d.step(us, vec![]).result.is_ok());
                }
                let good =
                    Arc::clone(&d.tree.length_runtime.as_ref().unwrap().tracks[&(id(1), axis)]);
                if failure == 0 {
                    let mut bad = (*good).clone();
                    bad.to.intrinsic -= 10.0;
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .insert((id(1), axis), Arc::new(bad));
                }
                let failed = d.attempt(
                    2_000_000,
                    vec![],
                    match failure {
                        0 => Injection::None,
                        1 => Injection::Query(QueryKind::PriorTarget),
                        _ => Injection::BeforeLayout,
                    },
                );
                assert!(failed.result.is_err());
                failed
                    .published_after
                    .as_ref()
                    .unwrap()
                    .assert_same(failed.published_before.as_ref().unwrap());
                if failure == 0 {
                    assert!(
                        matches!(failed.result,Err(AttemptError::Native(ProjectionError::ReleaseMismatch(node,a))) if node==id(1)&&a==axis)
                    );
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .insert((id(1), axis), good);
                }
                let retry = d.step(2_100_000, vec![]);
                assert!(retry.result.is_ok(), "{:?}", retry.result);
                close(
                    capture_axis(&d.tree, &id(1), axis).unwrap().intrinsic,
                    305.0,
                );
                close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 152.5);
                assert!(d.runtime.groups.is_empty());
                assert!(d.tree.length_runtime.is_none());
            }
        }
    }
}

fn pixel_boundary_parent(axis: Axis, segment: bool) -> ElementTree {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
    tree.get_mut(&id(2))
        .unwrap()
        .spec
        .declared
        .animate
        .as_mut()
        .unwrap()
        .duration_ms = 2000.0;
    let mut parent = spec(Length::Px(600.0), Length::Px(800.0), 2000.0, axis);
    if segment {
        parent.keyframes.push(parent.keyframes[0].clone());
        parent.duration_ms = 4000.0;
    }
    parent.repeat = AnimationRepeat::Loop;
    tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(parent);
    tree
}
#[test]
fn finite_release_replays_pixel_clock_segment_and_cycle_boundaries_without_rewinding_them() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for segment in [false, true] {
                for skipped in [false, true] {
                    for scale in [0.5, 1.0, 2.0] {
                        for repeat in [AnimationRepeat::Loop, AnimationRepeat::Times(2000)] {
                            let mut tree = pixel_boundary_parent(axis, segment);
                            tree.get_mut(&id(1))
                                .unwrap()
                                .spec
                                .declared
                                .animate
                                .as_mut()
                                .unwrap()
                                .repeat = repeat;
                            let mut d = Driver::new(tree, Instant::now(), mode);
                            assert!(
                                d.step(
                                    0,
                                    vec![Event::Viewport {
                                        width: 600.0 * scale,
                                        height: 600.0 * scale,
                                        scale
                                    }]
                                )
                                .result
                                .is_ok()
                            );
                            for us in [500_000, 1_000_000, 1_500_000] {
                                assert!(d.step(us, vec![]).result.is_ok());
                            }
                            let (us, parent) = if skipped {
                                (2_001_750_000, 775.0)
                            } else {
                                (2_000_000, if segment { 800.0 } else { 600.0 })
                            };
                            let out = d.step(us, vec![]);
                            assert!(
                                out.result.is_ok(),
                                "{axis:?} segment={segment} {us}: {:?}",
                                out.result
                            );
                            close(capture_axis(&d.tree, &id(1), axis).unwrap().visible, parent);
                            close(
                                capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                                parent / 2.0,
                            );
                            assert!(out.inspection.queries.len() <= 2);
                            assert!(d.tree.length_runtime.is_none());
                            assert!(d.runtime.groups.is_empty());
                        }
                    }
                }
            }
        }
    }
}

#[test]
fn pixel_boundary_release_keeps_native_corruption_checks_and_failed_output_retry_clocks() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for failure in 0..3 {
                let mut d = Driver::new(pixel_boundary_parent(axis, false), Instant::now(), mode);
                for us in [0, 500_000, 1_000_000, 1_500_000] {
                    assert!(d.step(us, vec![]).result.is_ok());
                }
                let good =
                    Arc::clone(&d.tree.length_runtime.as_ref().unwrap().tracks[&(id(2), axis)]);
                if failure == 0 {
                    let mut bad = (*good).clone();
                    bad.to.charge -= 10.0;
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .insert((id(2), axis), Arc::new(bad));
                }
                let failed = d.attempt(
                    2_000_000,
                    vec![],
                    match failure {
                        0 => Injection::None,
                        1 => Injection::Query(QueryKind::PriorTarget),
                        _ => Injection::BeforeLayout,
                    },
                );
                assert!(failed.result.is_err());
                failed
                    .published_after
                    .as_ref()
                    .unwrap()
                    .assert_same(failed.published_before.as_ref().unwrap());
                if failure == 0 {
                    assert!(
                        matches!(failed.result,Err(AttemptError::Native(ProjectionError::ReleaseMismatch(node,a))) if node==id(2)&&a==axis)
                    );
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .insert((id(2), axis), good);
                }
                let retry = d.step(2_100_000, vec![]);
                assert!(retry.result.is_ok(), "{:?}", retry.result);
                close(capture_axis(&d.tree, &id(1), axis).unwrap().visible, 610.0);
                close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 305.0);
                assert!(d.runtime.groups.is_empty());
                assert!(d.tree.length_runtime.is_none());
            }
        }
    }
}
#[test]
fn pixel_cycle_release_exception_does_not_preserve_a_moving_anchor_across_a_reset() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut tree = pixel_boundary_parent(axis, false);
            tree.get_mut(&id(2))
                .unwrap()
                .spec
                .declared
                .animate
                .as_mut()
                .unwrap()
                .duration_ms = 4000.0;
            let mut d = Driver::new(tree, Instant::now(), mode);
            for us in [0, 500_000, 1_000_000, 1_500_000, 2_000_000] {
                assert!(d.step(us, vec![]).result.is_ok());
            }
            close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 207.5);
            assert!(d.step(2_500_000, vec![]).result.is_ok());
            close(
                capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                236.875,
            );
            assert!(d.step(4_000_000, vec![]).result.is_ok());
            close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 300.0);
        }
    }
}

fn mixed_boundary_parent(axis: Axis, reverse: bool, segment: bool) -> ElementTree {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
    tree.get_mut(&id(2))
        .unwrap()
        .spec
        .declared
        .animate
        .as_mut()
        .unwrap()
        .duration_ms = 2000.0;
    let (from, to) = if reverse {
        (Length::Fill, Length::Px(200.0))
    } else {
        (Length::Px(200.0), Length::Fill)
    };
    let mut parent = spec(from, to, 2000.0, axis);
    if segment {
        parent.keyframes.push(parent.keyframes[0].clone());
        parent.duration_ms = 4000.0;
    }
    parent.repeat = AnimationRepeat::Loop;
    tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(parent);
    tree
}

#[test]
fn finite_release_follows_mixed_parent_segment_and_repeat_boundaries() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for reverse in [false, true] {
                for segment in [false, true] {
                    for scale in [0.5, 1.0, 2.0] {
                        for curve in [
                            AnimationCurve::Linear,
                            AnimationCurve::EaseIn,
                            AnimationCurve::EaseOut,
                            AnimationCurve::EaseInOut,
                        ] {
                            for deadline in [2_000_000, 2_100_000, 2_001_100_000] {
                                let mut tree = mixed_boundary_parent(axis, reverse, segment);
                                for node in [1, 2] {
                                    tree.get_mut(&id(node))
                                        .unwrap()
                                        .spec
                                        .declared
                                        .animate
                                        .as_mut()
                                        .unwrap()
                                        .curve = curve.clone();
                                }
                                let mut d = Driver::new(tree, Instant::now(), mode);
                                assert!(
                                    d.step(
                                        0,
                                        vec![Event::Viewport {
                                            width: 600.0 * scale,
                                            height: 600.0 * scale,
                                            scale
                                        }]
                                    )
                                    .result
                                    .is_ok()
                                );
                                for us in [500_000, 1_750_000, deadline] {
                                    let out = d.step(us, vec![]);
                                    assert!(
                                        out.result.is_ok(),
                                        "{axis:?} {mode:?} reverse={reverse} segment={segment} {us}: {:?}",
                                        out.result
                                    );
                                    assert!(
                                        out.inspection.queries.len() <= 8,
                                        "{}",
                                        out.inspection.queries.len()
                                    );
                                    assert!(out.inspection.after.model_copies <= 1);
                                }
                                let time = deadline % if segment { 4_000_000 } else { 2_000_000 };
                                let phase =
                                    apply_curve(&curve, (time % 2_000_000) as f64 / 2_000_000.0)
                                        as f32;
                                let descending = reverse ^ (time >= 2_000_000);
                                let parent = if descending {
                                    600.0 - 400.0 * phase
                                } else {
                                    200.0 + 400.0 * phase
                                };
                                close(capture_axis(&d.tree, &id(1), axis).unwrap().visible, parent);
                                close(
                                    capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                                    parent / 2.0,
                                );
                                assert!(d.runtime.groups.is_empty());
                                assert!(
                                    !d.tree
                                        .length_runtime
                                        .as_ref()
                                        .unwrap()
                                        .tracks
                                        .contains_key(&(id(2), axis))
                                );
                            }
                        }
                    }
                }
            }
        }
    }
}

#[test]
fn mixed_boundary_proofs_preserve_corruption_checks_and_failed_attempts() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for segment in [false, true] {
                for failure in 0..8 {
                    let mut d = Driver::new(
                        mixed_boundary_parent(axis, false, segment),
                        Instant::now(),
                        mode,
                    );
                    assert!(d.step(0, vec![]).result.is_ok());
                    let before = d.step(1_750_000, vec![]).published_after.unwrap();
                    let old =
                        d.tree.length_runtime.as_ref().unwrap().tracks[&(id(1), axis)].clone();
                    if failure < 2 {
                        let track = Arc::make_mut(
                            d.tree
                                .length_runtime
                                .as_mut()
                                .unwrap()
                                .tracks
                                .get_mut(&(id(1), axis))
                                .unwrap(),
                        );
                        if failure == 0 {
                            track.to.intrinsic += 20.0;
                        } else {
                            track.to.policy.fill_request *= 0.5;
                        }
                    }
                    let injection = match failure {
                        0 | 1 => Injection::None,
                        2 => Injection::Query(QueryKind::Target),
                        3 => Injection::Query(QueryKind::Release),
                        4 => Injection::Query(QueryKind::PriorTarget),
                        5 => Injection::Query(QueryKind::ForeignTarget),
                        6 if !segment => Injection::Query(QueryKind::Source),
                        _ => Injection::BeforeLayout,
                    };
                    let out = d.attempt(2_000_000, vec![], injection);
                    assert!(
                        out.result.is_err(),
                        "{axis:?} {mode:?} segment={segment} failure={failure}"
                    );
                    if failure < 2 {
                        assert_eq!(
                            out.result,
                            Err(AttemptError::Native(ProjectionError::ReleaseMismatch(
                                id(1),
                                axis
                            )))
                        );
                    }
                    out.published_after.unwrap().assert_same(&before);
                    if failure < 2 {
                        d.tree
                            .length_runtime
                            .as_mut()
                            .unwrap()
                            .tracks
                            .insert((id(1), axis), old);
                    }
                    let out = d.step(2_100_000, vec![]);
                    assert!(out.result.is_ok(), "{failure}: {:?}", out.result);
                    let parent = if segment { 580.0 } else { 220.0 };
                    close(capture_axis(&d.tree, &id(1), axis).unwrap().visible, parent);
                    close(
                        capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                        parent / 2.0,
                    );
                    assert!(d.runtime.groups.is_empty());
                }
            }
        }
    }
}

#[test]
fn content_boundary_release_matches_native_full_footprints_not_pixel_lowering() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for reverse in [false, true] {
                let mut tree = mixed_boundary_parent(axis, reverse, false);
                let parent = tree
                    .get_mut(&id(1))
                    .unwrap()
                    .spec
                    .declared
                    .animate
                    .as_mut()
                    .unwrap();
                let index = if reverse { 1 } else { 0 };
                match axis {
                    Axis::Width => parent.keyframes[index].width = Some(Length::Content),
                    Axis::Height => parent.keyframes[index].height = Some(Length::Content),
                };
                let mut d = Driver::new(tree, Instant::now(), mode);
                for us in [0, 500_000, 1_750_000] {
                    let out = d.step(us, vec![]);
                    assert!(out.result.is_ok(), "{us}: {:?}", out.result);
                }
                let out = d.step(2_100_000, vec![]);
                assert!(
                    out.result.is_ok(),
                    "{axis:?} reverse={reverse}: {:?}",
                    out.result
                );
                let native = &out
                    .inspection
                    .queries
                    .iter()
                    .find(|q| q.kind == QueryKind::Release)
                    .unwrap()
                    .result
                    .as_ref()
                    .unwrap()[&(id(2), axis)];
                assert!(
                    capture_axis(&d.tree, &id(2), axis)
                        .unwrap()
                        .release_matches(*native)
                );
                assert!(d.runtime.groups.is_empty());
            }
        }
    }
}

#[test]
fn retained_pixel_intervals_use_full_boundary_witnesses_at_finite_release() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut tree = mixed_boundary_parent(axis, true, false);
            tree.get_mut(&id(2))
                .unwrap()
                .spec
                .declared
                .animate
                .as_mut()
                .unwrap()
                .duration_ms = 4000.0;
            let parent = tree
                .get_mut(&id(1))
                .unwrap()
                .spec
                .declared
                .animate
                .as_mut()
                .unwrap();
            parent.duration_ms = 6000.0;
            parent.keyframes.extend([400.0, 600.0].map(|pixels| {
                let mut attrs = Attrs::default();
                match axis {
                    Axis::Width => attrs.width = Some(Length::Px(pixels)),
                    Axis::Height => attrs.height = Some(Length::Px(pixels)),
                };
                attrs
            }));
            let mut d = Driver::new(tree, Instant::now(), mode);
            for us in [0, 1_000_000, 2_500_000, 3_750_000, 4_100_000] {
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{us}: {:?}", out.result);
            }
            close(capture_axis(&d.tree, &id(1), axis).unwrap().visible, 410.0);
            close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 205.0);
            assert!(d.runtime.groups.is_empty());
        }
    }
}

#[test]
fn mixed_boundary_release_does_not_preserve_nonrelease_anchors_across_resets() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut tree = mixed_boundary_parent(axis, false, false);
            tree.get_mut(&id(2))
                .unwrap()
                .spec
                .declared
                .animate
                .as_mut()
                .unwrap()
                .duration_ms = 4000.0;
            let mut d = Driver::new(tree, Instant::now(), mode);
            for us in [0, 1_750_000] {
                assert!(d.step(us, vec![]).result.is_ok());
            }
            for (us, expected) in [(2_000_000, 157.5), (2_500_000, 155.625), (4_000_000, 100.0)] {
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{us}: {:?}", out.result);
                close(
                    capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                    expected,
                );
            }
        }
    }
}

#[test]
fn weighted_foreign_boundary_releases_preserve_parent_pool_charges() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for scale in [0.5, 1.0, 2.0] {
                let mut tree = mixed_boundary_parent(axis, false, false);
                let mut parent = spec(
                    Length::FillWeighted(1.0),
                    Length::FillWeighted(3.0),
                    2000.0,
                    axis,
                );
                parent.repeat = AnimationRepeat::Loop;
                tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(parent);
                tree.insert(Element::with_attrs(
                    id(10),
                    if axis == Axis::Width {
                        ElementKind::Row
                    } else {
                        ElementKind::Column
                    },
                    vec![],
                    Attrs {
                        width: Some(Length::Px(600.0)),
                        height: Some(Length::Px(600.0)),
                        ..Default::default()
                    },
                ));
                tree.insert(Element::with_attrs(
                    id(11),
                    ElementKind::El,
                    vec![],
                    Attrs {
                        width: Some(Length::Fill),
                        height: Some(Length::Fill),
                        ..Default::default()
                    },
                ));
                tree.set_children(&id(10), vec![id(1), id(11)]).unwrap();
                tree.set_root_id(id(10));
                let mut d = Driver::new(tree, Instant::now(), mode);
                assert!(
                    d.step(
                        0,
                        vec![Event::Viewport {
                            width: 600.0 * scale,
                            height: 600.0 * scale,
                            scale
                        }]
                    )
                    .result
                    .is_ok()
                );
                for us in [500_000, 1_750_000, 2_100_000] {
                    let out = d.step(us, vec![]);
                    assert!(out.result.is_ok(), "{axis:?} {us}: {:?}", out.result);
                }
                let parent = capture_axis(&d.tree, &id(1), axis).unwrap();
                close(parent.visible, 307.5);
                close(parent.charge, 307.5);
                close(capture_axis(&d.tree, &id(11), axis).unwrap().visible, 292.5);
                close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 153.75);
                assert!(d.runtime.groups.is_empty());
            }
        }
    }
}

#[test]
fn mixed_boundary_resolves_both_foreign_axes_before_joint_release() {
    for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
        let mut tree = mixed_boundary_parent(Axis::Width, false, false);
        for node in [1, 2] {
            let spec = tree
                .get_mut(&id(node))
                .unwrap()
                .spec
                .declared
                .animate
                .as_mut()
                .unwrap();
            for attrs in &mut spec.keyframes {
                attrs.height = attrs.width.clone();
            }
        }
        let mut d = Driver::new(tree, Instant::now(), mode);
        for us in [0, 500_000, 1_750_000, 2_100_000] {
            let out = d.step(us, vec![]);
            assert!(out.result.is_ok(), "{us}: {:?}", out.result);
            assert!(
                out.inspection.queries.len() <= 12,
                "{}",
                out.inspection.queries.len()
            );
        }
        close(
            capture_axis(&d.tree, &id(1), Axis::Width).unwrap().visible,
            220.0,
        );
        close(
            capture_axis(&d.tree, &id(1), Axis::Height).unwrap().visible,
            220.0,
        );
        close(
            capture_axis(&d.tree, &id(2), Axis::Width).unwrap().visible,
            110.0,
        );
        close(
            capture_axis(&d.tree, &id(2), Axis::Height).unwrap().visible,
            220.0,
        );
        assert!(d.runtime.groups.is_empty());
    }
}

fn independent_mixed_panels(axis: Axis) -> ElementTree {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
    let mut parent = spec(Length::Px(200.0), Length::Fill, 2000.0, axis);
    parent.repeat = AnimationRepeat::Loop;
    tree.get_mut(&id(1)).unwrap().spec.declared.animate = Some(parent);
    let mut other = Attrs {
        width: Some(Length::Px(600.0)),
        height: Some(Length::Px(600.0)),
        ..Default::default()
    };
    let mut animation = spec(Length::Px(100.0), Length::Fill, 3000.0, axis);
    animation.repeat = AnimationRepeat::Loop;
    other.animate = Some(animation);
    tree.insert(Element::with_attrs(id(5), ElementKind::El, vec![], other));
    tree.insert(Element::with_attrs(
        id(10),
        if axis == Axis::Width {
            ElementKind::Column
        } else {
            ElementKind::Row
        },
        vec![],
        Attrs {
            width: Some(Length::Px(600.0)),
            height: Some(Length::Px(600.0)),
            ..Default::default()
        },
    ));
    tree.set_children(&id(10), vec![id(1), id(5)]).unwrap();
    tree.set_root_id(id(10));
    tree
}

#[test]
fn unrelated_mixed_panels_do_not_restart_or_block_a_finite_child() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut d = Driver::new(independent_mixed_panels(axis), Instant::now(), mode);
            for (us, expected) in [(0, 40.0), (500_000, 95.0), (1_000_000, 200.0)] {
                let out = d.step(us, vec![]);
                assert!(
                    out.result.is_ok(),
                    "{axis:?} {mode:?} {us}: {:?}",
                    out.result
                );
                close(
                    capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                    expected,
                );
            }
            assert!(d.runtime.groups.is_empty());
        }
    }
}

fn mixed_peer_pool(axis: Axis) -> ElementTree {
    let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
    let mut peer = spec(Length::Px(200.0), Length::Fill, 2000.0, axis);
    peer.repeat = AnimationRepeat::Loop;
    tree.get_mut(&id(3)).unwrap().spec.declared.animate = Some(peer);
    tree
}

#[test]
fn same_pool_mixed_changes_are_not_mistaken_for_independence() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut d = Driver::new(mixed_peer_pool(axis), Instant::now(), mode);
            assert!(d.step(0, vec![]).result.is_ok());
            let out = d.step(500_000, vec![]);
            assert!(out.result.is_ok(), "{:?}", out.result);
            close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 220.0);
            let target = out
                .inspection
                .queries
                .iter()
                .find(|q| {
                    q.kind == QueryKind::IndependentContext
                        && q.result
                            .as_ref()
                            .is_ok_and(|v| v.contains_key(&(id(2), axis)))
                })
                .unwrap()
                .result
                .as_ref()
                .unwrap()[&(id(2), axis)];
            close(target.visible, 310.0);
            // Corrupt the original cached target to exactly match that new native
            // target. The original projection must still reject this, rather
            // than laundering it through the independence comparison.
            let mut d = Driver::new(mixed_peer_pool(axis), Instant::now(), mode);
            let before = d.step(0, vec![]).published_after.unwrap();
            Arc::make_mut(
                d.tree
                    .length_runtime
                    .as_mut()
                    .unwrap()
                    .tracks
                    .get_mut(&(id(2), axis))
                    .unwrap(),
            )
            .to = target;
            let out = d.step(500_000, vec![]);
            assert_eq!(
                out.result,
                Err(AttemptError::Native(ProjectionError::ReleaseMismatch(
                    id(2),
                    axis
                )))
            );
            out.published_after.unwrap().assert_same(&before);
        }
    }
}

#[test]
fn independence_witness_failures_preserve_sources_and_retry_clocks() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for failure in 0..5 {
                let mut d = Driver::new(independent_mixed_panels(axis), Instant::now(), mode);
                let before = d.step(0, vec![]).published_after.unwrap();
                let old = d.tree.length_runtime.as_ref().unwrap().tracks[&(id(1), axis)].clone();
                if failure == 0 {
                    Arc::make_mut(
                        d.tree
                            .length_runtime
                            .as_mut()
                            .unwrap()
                            .tracks
                            .get_mut(&(id(1), axis))
                            .unwrap(),
                    )
                    .to
                    .policy
                    .fill_request *= 0.5;
                }
                let injection = match failure {
                    0 => Injection::None,
                    1 => Injection::Query(QueryKind::PriorTarget),
                    2 => Injection::Query(QueryKind::IndependentContext),
                    3 => Injection::Query(QueryKind::ForeignTarget),
                    _ => Injection::BeforeLayout,
                };
                let out = d.attempt(500_000, vec![], injection);
                assert!(out.result.is_err());
                out.published_after.unwrap().assert_same(&before);
                if failure == 0 {
                    d.tree
                        .length_runtime
                        .as_mut()
                        .unwrap()
                        .tracks
                        .insert((id(1), axis), old);
                }
                let out = d.step(750_000, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 141.25);
                assert!(d.step(1_000_000, vec![]).result.is_ok());
                assert!(d.runtime.groups.is_empty());
            }
        }
    }
}

#[test]
fn independent_boundary_panels_follow_curves_at_each_scale_and_query_order() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            for scale in [0.5, 1.0, 2.0] {
                for curve in [
                    AnimationCurve::Linear,
                    AnimationCurve::EaseIn,
                    AnimationCurve::EaseOut,
                    AnimationCurve::EaseInOut,
                ] {
                    for reverse_order in [false, true] {
                        let mut tree = independent_mixed_panels(axis);
                        tree.get_mut(&id(2))
                            .unwrap()
                            .spec
                            .declared
                            .animate
                            .as_mut()
                            .unwrap()
                            .duration_ms = 2000.0;
                        for node in [1, 2, 5] {
                            tree.get_mut(&id(node))
                                .unwrap()
                                .spec
                                .declared
                                .animate
                                .as_mut()
                                .unwrap()
                                .curve = curve.clone();
                        }
                        if reverse_order {
                            tree.set_children(&id(10), vec![id(5), id(1)]).unwrap();
                        }
                        let mut d = Driver::new(tree, Instant::now(), mode);
                        assert!(
                            d.step(
                                0,
                                vec![Event::Viewport {
                                    width: 600.0 * scale,
                                    height: 600.0 * scale,
                                    scale
                                }]
                            )
                            .result
                            .is_ok()
                        );
                        for us in [500_000, 1_750_000, 2_100_000] {
                            let out = d.step(us, vec![]);
                            assert!(
                                out.result.is_ok(),
                                "{axis:?} {mode:?} {curve:?} {us}: {:?}",
                                out.result
                            );
                            assert!(out.inspection.after.model_copies <= 1);
                            let t = us as f64 / 1_000_000.0;
                            let parent = 200.0 + 400.0 * apply_curve(&curve, (t % 2.0) / 2.0);
                            let expected = if t < 2.0 {
                                40.0 + (parent / 2.0 - 40.0) * apply_curve(&curve, t / 2.0)
                            } else {
                                parent / 2.0
                            };
                            close(
                                capture_axis(&d.tree, &id(2), axis).unwrap().visible,
                                expected as f32,
                            );
                        }
                        assert!(d.runtime.groups.is_empty());
                    }
                }
            }
        }
    }
}

#[test]
fn release_checks_the_actual_continued_foreign_sample_before_publication() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut tree = independent_mixed_panels(axis);
            tree.get_mut(&id(1)).unwrap().spec.declared.animate = None;
            let mut parent = spec(Length::Px(100.0), Length::Content, 2000.0, axis);
            parent.repeat = AnimationRepeat::Loop;
            tree.get_mut(&id(5)).unwrap().spec.declared.animate = Some(parent);
            let mut child = spec(Length::Px(200.0), Length::Px(400.0), 2000.0, axis);
            child.repeat = AnimationRepeat::Loop;
            tree.insert(Element::with_attrs(
                id(6),
                ElementKind::El,
                vec![],
                Attrs {
                    animate: Some(child),
                    ..Default::default()
                },
            ));
            tree.set_children(&id(5), vec![id(6)]).unwrap();
            let mut d = Driver::new(tree, Instant::now(), mode);
            assert!(d.step(0, vec![]).result.is_ok());
            let before = d.step(500_000, vec![]).published_after.unwrap();
            close(capture_axis(&d.tree, &id(5), axis).unwrap().visible, 137.5);
            let out = d.attempt(
                1_000_000,
                vec![],
                Injection::Query(QueryKind::CurrentRelease),
            );
            assert_eq!(
                out.result,
                Err(AttemptError::Native(ProjectionError::InjectedQuery))
            );
            out.published_after.unwrap().assert_same(&before);
            let out = d.step(1_100_000, vec![]);
            assert!(out.result.is_ok(), "{:?}", out.result);
            close(capture_axis(&d.tree, &id(5), axis).unwrap().visible, 215.5);
            close(capture_axis(&d.tree, &id(2), axis).unwrap().visible, 300.0);
            assert!(d.runtime.groups.is_empty());
        }
    }
}

#[test]
fn retired_query_work_includes_terminal_queries_without_retaining_a_workspace() {
    for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
        let mut d = Driver::new(
            fixture(Length::Px(40.0), Length::Fill, Axis::Width),
            Instant::now(),
            mode,
        );
        assert!(d.step(0, vec![]).result.is_ok());
        assert!(d.step(500_000, vec![]).result.is_ok());
        let before = d.tree.length_runtime.as_ref().unwrap().query_stats();
        assert_eq!(d.tree.animation_query_retirement.count, 0);
        assert!(d.step(1_000_000, vec![]).result.is_ok());
        assert!(d.tree.length_runtime.is_none());
        let work = &d.tree.animation_query_retirement;
        assert_eq!(work.count, 1);
        assert_eq!(work.model_copies, 1);
        assert_eq!(work.copied_nodes, d.tree.len() as u64);
        assert!(work.layout_queries > before.layout_queries);
        assert_eq!(work.layout_queries, work.last.layout_queries);
        let queries = work.layout_queries;
        let mut attrs = d.attrs(id(2));
        attrs.animate = Some(spec(Length::Fill, Length::Px(40.0), 1000.0, Axis::Width));
        assert!(
            d.step(1_000_001, vec![Event::Attrs(id(2), Box::new(attrs))])
                .result
                .is_ok()
        );
        assert!(d.step(2_000_001, vec![]).result.is_ok());
        assert!(d.tree.length_runtime.is_none());
        let work = &d.tree.animation_query_retirement;
        assert_eq!(work.count, 2);
        assert_eq!(work.layout_queries, queries + work.last.layout_queries);
        assert_eq!(work.model_copies, 2);
    }
}

#[test]
fn independent_consumers_share_only_matching_native_input_cohorts() {
    for axis in [Axis::Width, Axis::Height] {
        for mode in [Mode::Full, Mode::Active, Mode::Dirty] {
            let mut tree = independent_mixed_panels(axis);
            let attrs = tree.get(&id(2)).unwrap().spec.declared.clone();
            for node in 20..83 {
                tree.insert(Element::with_attrs(
                    id(node),
                    ElementKind::El,
                    vec![],
                    attrs.clone(),
                ));
            }
            tree.set_children(
                &id(1),
                [id(2), id(3)].into_iter().chain((20..83).map(id)).collect(),
            )
            .unwrap();
            let mut d = Driver::new(tree, Instant::now(), mode);
            for (us, parent, p) in [
                (0, 200.0, 0.0),
                (500_000, 300.0, 0.5),
                (1_000_000, 400.0, 1.0),
            ] {
                let visits = d
                    .tree
                    .animation_query_retirement
                    .continuation_ancestry_visits
                    .get();
                let out = d.step(us, vec![]);
                assert!(out.result.is_ok(), "{:?}", out.result);
                assert!(
                    out.inspection.queries.len() <= 8,
                    "{us}: {}",
                    out.inspection.queries.len()
                );
                assert!(
                    d.tree
                        .animation_query_retirement
                        .continuation_ancestry_visits
                        .get()
                        - visits
                        <= 5_000
                );
                assert_eq!(out.inspection.after.model_copies, 1);
                for node in [2].into_iter().chain(20..83) {
                    close(
                        capture_axis(&d.tree, &id(node), axis).unwrap().visible,
                        40.0 + (parent / 65.0 - 40.0) * p,
                    );
                }
            }
            assert!(d.runtime.groups.is_empty());
        }
    }
}

#[test]
fn coupled_mixed_deadlines_are_not_authorized_as_independent_contexts() {
    // P1 negative-proof baselines, NOT desired public completion semantics.
    // P2.2 must replace these rejection expectations with a certified coupled
    // release rule. Never "fix" them by accepting the independence candidate.
    for axis in [Axis::Width, Axis::Height] {
        for upward in [false, true] {
            let tree = if upward {
                let mut tree = fixture(Length::Px(40.0), Length::Fill, axis);
                tree.get_mut(&id(1)).unwrap().spec.declared.animate =
                    Some(spec(Length::Px(200.0), Length::Content, 1000.0, axis));
                let child = tree
                    .get_mut(&id(2))
                    .unwrap()
                    .spec
                    .declared
                    .animate
                    .as_mut()
                    .unwrap();
                child.repeat = AnimationRepeat::Loop;
                child.duration_ms = 2000.0;
                tree
            } else {
                mixed_peer_pool(axis)
            };
            let mut d = Driver::new(tree, Instant::now(), Mode::Full);
            assert!(d.step(0, vec![]).result.is_ok());
            let before = d.step(500_000, vec![]).published_after.unwrap();
            let out = d.step(1_000_000, vec![]);
            println!(
                "coupled_deadline axis={axis:?} upward={upward} result={:?}",
                out.result
            );
            assert_eq!(
                out.result,
                Err(AttemptError::Native(ProjectionError::ReleaseMismatch(
                    id(if upward { 1 } else { 2 }),
                    axis
                )))
            );
            out.published_after.unwrap().assert_same(&before);
        }
    }
}
