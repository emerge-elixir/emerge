defmodule Emerge.Engine.SerializationTest do
  use ExUnit.Case, async: true

  use Emerge.UI

  alias Emerge.Engine.Serialization
  alias Emerge.Engine.Tree

  test "assign_ids assigns stable integer ids" do
    layout =
      column([key(10)], [
        el([key(12)], text("a")),
        el([key(13)], text("b"))
      ])

    {tree, _state} = Tree.assign_ids(layout)

    assert is_integer(tree.id)
    assert is_integer(Enum.at(tree.children, 0).id)
    assert is_integer(Enum.at(tree.children, 1).id)
  end

  test "assign_ids is deterministic for the same tree" do
    layout =
      row([key(:root)], [
        el([key({:card, 1})], text("a")),
        el([key({:card, 2})], text("b"))
      ])

    {tree, _state} = Tree.assign_ids(layout)
    {tree2, _state2} = Tree.assign_ids(layout)

    assert tree.id == tree2.id
    assert Enum.at(tree.children, 0).id == Enum.at(tree2.children, 0).id
    assert Enum.at(tree.children, 1).id == Enum.at(tree2.children, 1).id
  end

  test "encode assigns ids and returns a binary" do
    layout =
      row([spacing(10)], [
        el([], text("a")),
        el([], text("b"))
      ])

    {binary, tree} = Serialization.encode(layout)

    assert is_binary(binary)
    assert is_integer(tree.id)
    assert is_integer(Enum.at(tree.children, 0).id)
    assert is_integer(Enum.at(tree.children, 1).id)
  end

  test "decode returns the same tree as encode (sans runtime attrs)" do
    layout =
      column([spacing(8)], [
        el([padding(4)], text("hello")),
        row([spacing(2)], [
          el([], text("a")),
          el([], text("b"))
        ])
      ])

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert strip_runtime(decoded) == strip_runtime(tree)
  end

  test "paragraph roundtrip preserves type and children" do
    layout =
      paragraph([spacing(6)], [
        text("Hello "),
        el([Emerge.UI.Font.bold()], text("world")),
        text(", this wraps.")
      ])

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert strip_runtime(decoded) == strip_runtime(tree)
    assert decoded.type == :paragraph
    assert length(decoded.children) == 3
  end

  test "text_column roundtrip preserves type, defaults, and children" do
    layout =
      text_column([spacing(10)], [
        paragraph([spacing(4)], [text("First paragraph")]),
        paragraph([spacing(4)], [text("Second paragraph")])
      ])

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert strip_runtime(decoded) == strip_runtime(tree)
    assert decoded.type == :text_column
    assert decoded.attrs.width == :fill
    assert decoded.attrs.height == :content
    assert length(decoded.children) == 2
  end

  test "image roundtrip preserves image attrs" do
    layout = image([width(px(300)), height(px(120)), image_fit(:cover)], "img_banner")

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert strip_runtime(decoded) == strip_runtime(tree)
    assert decoded.type == :image
    assert decoded.attrs.image_src == "img_banner"
    assert decoded.attrs.image_fit == :cover
  end

  test "text_input roundtrip preserves content and handlers" do
    layout =
      Emerge.UI.Input.text(
        [
          width(px(280)),
          focus_on_mount(),
          Event.on_change({self(), :changed}),
          Event.on_focus({self(), :focused}),
          Event.on_blur({self(), :blurred}),
          Interactive.focused([
            Transform.alpha(0.9),
            Transform.move_x(2),
            Emerge.UI.Border.glow(:cyan, 3)
          ]),
          Interactive.mouse_down([
            Transform.move_y(-1),
            Transform.scale(0.98),
            Emerge.UI.Border.inner_shadow(offset: {0, 1}, blur: 6, size: 1, color: :black)
          ])
        ],
        "hello"
      )

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert tree.type == :text_input
    assert decoded.type == :text_input
    assert decoded.attrs.content == "hello"
    assert decoded.attrs.focus_on_mount == true
    assert decoded.attrs.on_change == true
    assert decoded.attrs.on_focus == true
    assert decoded.attrs.on_blur == true

    assert decoded.attrs.focused == %{
             alpha: 0.9,
             move_x: 2.0,
             box_shadow: [
               %{offset_x: 0.0, offset_y: 0.0, blur: 6.0, size: 3.0, color: :cyan, inset: false}
             ]
           }

    assert decoded.attrs.mouse_down == %{
             move_y: -1.0,
             scale: 0.98,
             box_shadow: [
               %{offset_x: 0.0, offset_y: 1.0, blur: 6.0, size: 1.0, color: :black, inset: true}
             ]
           }
  end

  test "multiline roundtrip preserves content and handlers" do
    layout =
      Emerge.UI.Input.multiline(
        [
          width(px(280)),
          Event.on_change({self(), :changed}),
          Event.on_key_down(:enter, {self(), :submitted})
        ],
        "hello\nworld"
      )

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert tree.type == :multiline
    assert decoded.type == :multiline
    assert decoded.attrs.content == "hello\nworld"
    assert decoded.attrs.on_change == true
    assert [%{key: :enter, mods: [], match: :exact}] = decoded.attrs.on_key_down
  end

  test "slider roundtrip preserves range, value, handlers, and slots" do
    track = el([height(px(6)), Background.color(:gray)], none())
    filled = el([height(px(6)), Background.color(:blue)], none())
    thumb = el([width(px(18)), height(px(18)), Background.color(:white)], none())

    layout =
      Emerge.UI.Input.slider(
        [
          width(px(280)),
          Slider.config(
            min: 0,
            max: 100,
            step: 5,
            track: track,
            filled_track: filled,
            thumb: thumb
          ),
          Event.on_change({self(), :changed})
        ],
        42
      )

    {binary, _tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert decoded.type == :slider
    assert decoded.attrs.slider_min == 0.0
    assert decoded.attrs.slider_max == 100.0
    assert decoded.attrs.slider_step == 5.0
    assert decoded.attrs.slider_value == 40.0
    assert decoded.attrs.on_change == true
    assert [decoded_track, decoded_filled, decoded_thumb] = decoded.children
    assert decoded_track.attrs.background == :gray
    assert decoded_track.attrs.height == {:px, 6.0}
    assert decoded_filled.attrs.background == :blue
    assert decoded_filled.attrs.height == {:px, 6.0}
    assert decoded_thumb.attrs.background == :white
    assert decoded_thumb.attrs.width == {:px, 18.0}
    assert decoded_thumb.attrs.height == {:px, 18.0}
  end

  test "input button roundtrip preserves press and focus handlers" do
    layout =
      Emerge.UI.Input.button(
        [
          Event.on_press({self(), :pressed}),
          Event.on_focus({self(), :focused}),
          Event.on_blur({self(), :blurred}),
          Interactive.focused([Transform.alpha(0.9), Emerge.UI.Border.glow(:cyan, 2)]),
          Interactive.mouse_down([
            Transform.move_y(-1),
            Emerge.UI.Border.inner_shadow(offset: {0, 1}, blur: 5, size: 1, color: :black)
          ])
        ],
        Emerge.UI.text("Save")
      )

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert tree.type == :el
    assert decoded.type == :el
    assert decoded.attrs.on_press == true
    assert decoded.attrs.on_focus == true
    assert decoded.attrs.on_blur == true

    assert decoded.attrs.focused == %{
             alpha: 0.9,
             box_shadow: [
               %{offset_x: 0.0, offset_y: 0.0, blur: 4.0, size: 2.0, color: :cyan, inset: false}
             ]
           }

    assert decoded.attrs.mouse_down == %{
             move_y: -1.0,
             box_shadow: [
               %{offset_x: 0.0, offset_y: 1.0, blur: 5.0, size: 1.0, color: :black, inset: true}
             ]
           }

    assert length(decoded.children) == 1
    assert hd(decoded.children).type == :text
    assert hd(decoded.children).attrs.content == "Save"
  end

  test "direct state style maps are normalized before serialization" do
    shadow = %{offset_x: 0, offset_y: 1, blur: 6, size: 2, color: :black, inset: true}

    layout =
      el(
        [
          {:mouse_over, %{alpha: 0.75, box_shadow: shadow}}
        ],
        text("Hello")
      )

    {binary, tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert tree.attrs.mouse_over == %{alpha: 0.75, box_shadow: [shadow]}

    assert decoded.attrs.mouse_over == %{
             alpha: 0.75,
             box_shadow: [
               %{offset_x: 0.0, offset_y: 1.0, blur: 6.0, size: 2.0, color: :black, inset: true}
             ]
           }
  end

  test "input button roundtrip preserves swipe handlers" do
    layout =
      Emerge.UI.Input.button(
        [
          Event.on_swipe_up({self(), :up}),
          Event.on_swipe_down({self(), :down}),
          Event.on_swipe_left({self(), :left}),
          Event.on_swipe_right({self(), :right})
        ],
        Emerge.UI.text("Save")
      )

    {binary, _tree} = Serialization.encode(layout)
    decoded = Serialization.decode(binary)

    assert decoded.attrs.on_swipe_up == true
    assert decoded.attrs.on_swipe_down == true
    assert decoded.attrs.on_swipe_left == true
    assert decoded.attrs.on_swipe_right == true
  end

  defp strip_runtime(%Emerge.Engine.Element{} = element) do
    %{
      element
      | key: nil,
        attrs: Emerge.Engine.Tree.strip_runtime_attrs(element.attrs),
        children: Enum.map(element.children, &strip_runtime/1),
        nearby: Enum.map(element.nearby, fn {slot, nearby} -> {slot, strip_runtime(nearby)} end)
    }
  end
end
