use super::super::*;
use super::common::*;
use crate::tree::attrs::FontWeight;

fn build_paragraph(
    paragraph_attrs: Attrs,
    children: Vec<(&str, ElementKind, Attrs)>,
) -> (ElementTree, NodeId, Vec<NodeId>) {
    let mut tree = ElementTree::new();

    let mut para = make_element("para", ElementKind::Paragraph, paragraph_attrs);
    let para_id = para.id;

    let mut child_ids = Vec::new();
    for (i, (name, kind, attrs)) in children.into_iter().enumerate() {
        let child_name = format!("{}_{}", name, i);
        let child = make_element(&child_name, kind, attrs);
        child_ids.push(child.id);
        tree.insert(child);
    }

    para.children = child_ids.clone();
    tree.set_root_id(para_id);
    tree.insert(para);

    (tree, para_id, child_ids)
}

fn paragraph_positions(tree: &ElementTree, id: NodeId) -> Vec<(f32, f32)> {
    tree.get(&id)
        .unwrap()
        .layout
        .paragraph_fragments
        .as_ref()
        .unwrap()
        .iter()
        .map(|fragment| (fragment.x, fragment.y))
        .collect()
}

#[test]
fn paragraph_alignment_positions_each_wrapped_line() {
    for (alignment, expected) in [
        (AlignX::Left, vec![(0.0, 0.0), (24.0, 0.0), (0.0, 16.0)]),
        (AlignX::Center, vec![(5.0, 0.0), (29.0, 0.0), (17.0, 16.0)]),
        (AlignX::Right, vec![(10.0, 0.0), (34.0, 0.0), (34.0, 16.0)]),
    ] {
        let (mut tree, id, _) = build_paragraph(
            Attrs {
                align_x: Some(alignment),
                ..fixed_width_attrs(50.0)
            },
            vec![("text", ElementKind::Text, text_attrs("AA BB CC"))],
        );
        layout_tree(
            &mut tree,
            Constraint::new(800.0, 600.0),
            1.0,
            &MockTextMeasurer,
        );
        assert_eq!(paragraph_positions(&tree, id), expected, "{alignment:?}");
    }
}

#[test]
fn paragraph_alignment_handles_empty_single_and_oversized_lines() {
    for (text, center_x, right_x) in [("", 0.0, 0.0), ("AA", 17.0, 34.0), ("AAAAAAA", 0.0, 0.0)] {
        for (alignment, x) in [(AlignX::Center, center_x), (AlignX::Right, right_x)] {
            let (mut tree, id, _) = build_paragraph(
                Attrs {
                    align_x: Some(alignment),
                    ..fixed_width_attrs(50.0)
                },
                vec![("text", ElementKind::Text, text_attrs(text))],
            );
            layout_tree(
                &mut tree,
                Constraint::new(800.0, 600.0),
                1.0,
                &MockTextMeasurer,
            );
            let expected = if text.is_empty() {
                vec![]
            } else {
                vec![(x, 0.0)]
            };
            assert_eq!(
                paragraph_positions(&tree, id),
                expected,
                "{alignment:?}: {text}"
            );
        }
    }
}

#[test]
fn paragraph_alignment_preserves_inline_spacing_and_ignores_trailing_spaces() {
    let (mut tree, id, _) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Center),
            ..fixed_width_attrs(50.0)
        },
        vec![
            ("a", ElementKind::Text, text_attrs("AA")),
            (
                "b",
                ElementKind::Text,
                Attrs {
                    font_size: Some(24.0),
                    text_align: Some(TextAlign::Right),
                    ..text_attrs(" BB")
                },
            ),
            ("c", ElementKind::Text, text_attrs(" CC ")),
        ],
    );
    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );
    assert_eq!(
        paragraph_positions(&tree, id),
        vec![(5.0, 0.0), (29.0, 0.0), (17.0, 24.0)]
    );

    // Leading whitespace stays in the line; a trailing space that wraps does not
    // count towards the line's alignment or prevent that line from finalizing.
    let (mut tree, id, _) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Center),
            ..fixed_width_attrs(50.0)
        },
        vec![("text", ElementKind::Text, text_attrs(" AA BB "))],
    );
    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );
    assert_eq!(
        paragraph_positions(&tree, id),
        vec![(9.0, 0.0), (33.0, 0.0)]
    );
}

#[test]
fn paragraph_alignment_uses_content_insets_and_line_spacing() {
    let (mut tree, id, _) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Right),
            padding: Some(Padding::Uniform(7.0)),
            border_width: Some(BorderWidth::Uniform(3.0)),
            spacing_y: Some(5.0),
            ..fixed_width_attrs(70.0)
        },
        vec![("text", ElementKind::Text, text_attrs("AA BB CC"))],
    );
    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );
    assert_eq!(
        paragraph_positions(&tree, id),
        vec![(20.0, 10.0), (44.0, 10.0), (44.0, 31.0)]
    );
}

#[test]
fn paragraph_alignment_tracks_float_bounds_before_and_after_expiry() {
    for (alignment, first_x, released_x) in
        [(AlignX::Center, 30.0, 6.0), (AlignX::Right, 40.0, 12.0)]
    {
        let (mut tree, id, floats) = build_paragraph(
            Attrs {
                align_x: Some(alignment),
                ..fixed_width_attrs(100.0)
            },
            vec![
                (
                    "left",
                    ElementKind::El,
                    Attrs {
                        align_x: Some(AlignX::Left),
                        ..fixed_box_attrs(20.0, 20.0)
                    },
                ),
                (
                    "right",
                    ElementKind::El,
                    Attrs {
                        align_x: Some(AlignX::Right),
                        ..fixed_box_attrs(20.0, 20.0)
                    },
                ),
                (
                    "text",
                    ElementKind::Text,
                    text_attrs("AA BB CC DD EE FF GG HH"),
                ),
            ],
        );
        layout_tree(
            &mut tree,
            Constraint::new(800.0, 600.0),
            1.0,
            &MockTextMeasurer,
        );
        assert_eq!(
            paragraph_positions(&tree, id),
            vec![
                (first_x, 0.0),
                (first_x + 24.0, 0.0),
                (first_x, 16.0),
                (first_x + 24.0, 16.0),
                (released_x, 32.0),
                (released_x + 24.0, 32.0),
                (released_x + 48.0, 32.0),
                (released_x + 72.0, 32.0),
            ]
        );
        assert_eq!(tree.get(&floats[0]).unwrap().layout.frame.unwrap().x, 0.0);
        assert_eq!(tree.get(&floats[1]).unwrap().layout.frame.unwrap().x, 80.0);
    }
}

#[test]
fn paragraph_alignment_finalizes_a_line_before_a_new_float() {
    let (mut tree, id, _) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Center),
            ..fixed_width_attrs(100.0)
        },
        vec![
            ("before", ElementKind::Text, text_attrs("AA BB")),
            (
                "float",
                ElementKind::El,
                Attrs {
                    align_x: Some(AlignX::Left),
                    ..fixed_box_attrs(24.0, 16.0)
                },
            ),
            ("after", ElementKind::Text, text_attrs("CC")),
        ],
    );
    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );
    assert_eq!(
        paragraph_positions(&tree, id),
        vec![(30.0, 0.0), (54.0, 0.0), (54.0, 16.0)]
    );
}

#[test]
fn paragraph_alignment_precedence_is_local_font_then_local_align_then_inherited_font() {
    for parent_kind in [
        ElementKind::El,
        ElementKind::Column,
        ElementKind::TextColumn,
    ] {
        for (align_x, text_align, inherited_align, expected_x) in [
            (None, None, None, 0.0),
            (None, None, Some(TextAlign::Center), 17.0),
            (None, None, Some(TextAlign::Right), 34.0),
            (Some(AlignX::Left), None, Some(TextAlign::Center), 0.0),
            (Some(AlignX::Center), None, Some(TextAlign::Right), 17.0),
            (
                Some(AlignX::Right),
                Some(TextAlign::Center),
                Some(TextAlign::Left),
                17.0,
            ),
            (
                Some(AlignX::Center),
                Some(TextAlign::Left),
                Some(TextAlign::Right),
                0.0,
            ),
        ] {
            let (mut tree, id, _) = build_paragraph(
                Attrs {
                    align_x,
                    text_align,
                    ..fixed_width_attrs(50.0)
                },
                vec![("text", ElementKind::Text, text_attrs("AA"))],
            );
            let mut parent = make_element(
                "parent",
                parent_kind,
                Attrs {
                    text_align: inherited_align,
                    ..fixed_width_attrs(50.0)
                },
            );
            parent.children = vec![id];
            tree.set_root_id(parent.id);
            tree.insert(parent);
            layout_tree(
                &mut tree,
                Constraint::new(800.0, 600.0),
                1.0,
                &MockTextMeasurer,
            );
            assert_eq!(
                paragraph_positions(&tree, id),
                vec![(expected_x, 0.0)],
                "{parent_kind:?}: local={align_x:?}/{text_align:?} inherited={inherited_align:?}"
            );
        }
    }
}

#[test]
fn paragraph_alignment_shared_floats_use_the_final_paragraph_box_position() {
    let (mut tree, id, _) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Center),
            ..fixed_width_attrs(100.0)
        },
        vec![("text", ElementKind::Text, text_attrs("AA BB CC"))],
    );
    let right_float = make_element(
        "right",
        ElementKind::El,
        Attrs {
            align_x: Some(AlignX::Right),
            ..fixed_box_attrs(100.0, 32.0)
        },
    );
    let mut parent = make_element("parent", ElementKind::TextColumn, fixed_width_attrs(200.0));
    parent.children = vec![right_float.id, id];
    tree.set_root_id(parent.id);
    tree.insert(parent);
    tree.insert(right_float);
    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );
    assert_eq!(tree.get(&id).unwrap().layout.frame.unwrap().x, 50.0);
    assert_eq!(
        paragraph_positions(&tree, id),
        vec![(55.0, 0.0), (79.0, 0.0), (67.0, 16.0)]
    );
}

#[test]
fn test_line_spacing_row_pushes_following_heading() {
    let mut tree = ElementTree::new();

    let col_attrs = Attrs {
        width: Some(Length::Px(20.0)),
        spacing: Some(12.0),
        ..Attrs::default()
    };
    let mut col = make_element("col", ElementKind::Column, col_attrs);

    let row_attrs = fill_width_attrs();
    let mut row = make_element("row", ElementKind::Row, row_attrs);

    let para_attrs = Attrs {
        width: Some(Length::Fill),
        spacing: Some(8.0),
        ..Attrs::default()
    };
    let mut para = make_element("para", ElementKind::Paragraph, para_attrs);

    let txt = make_element("txt", ElementKind::Text, text_attrs("AA BB"));

    let heading = make_element("heading", ElementKind::Text, text_attrs("Document Style"));

    let col_id = col.id;
    let row_id = row.id;
    let para_id = para.id;
    let txt_id = txt.id;
    let heading_id = heading.id;

    para.children = vec![txt_id];
    row.children = vec![para_id];
    col.children = vec![row_id, heading_id];

    tree.set_root_id(col_id);
    tree.insert(col);
    tree.insert(row);
    tree.insert(para);
    tree.insert(txt);
    tree.insert(heading);

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let row_frame = tree.get(&row_id).unwrap().layout.frame.unwrap();
    // Two lines with spacing(8): 16 + 8 + 16 = 40
    assert_eq!(row_frame.height, 40.0);

    let heading_frame = tree.get(&heading_id).unwrap().layout.frame.unwrap();
    // heading y = row height (40) + column spacing (12)
    assert_eq!(heading_frame.y, 52.0);
}

#[test]
fn test_paragraph_single_text_no_wrap() {
    // "Hello" = 5 chars * 8px = 40px, fits within 200px
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(200.0),
        vec![("t", ElementKind::Text, text_attrs("Hello"))],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 1);
    assert_eq!(fragments[0].text, "Hello");
    assert_eq!(fragments[0].x, 0.0);
    assert_eq!(fragments[0].y, 0.0);
}

#[test]
fn test_paragraph_wraps_words() {
    // "AA BB CC" -> 3 words: "AA" (16px), "BB" (16px), "CC" (16px)
    // space = 8px
    // Container 40px wide:
    // "AA" (16) fits, + space (8) + "BB" (16) = 40 fits
    // + space (8) + "CC" (16) = 64 > 40, "CC" wraps
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(40.0),
        vec![("t", ElementKind::Text, text_attrs("AA BB CC"))],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 3);

    // Line 1: "AA" at x=0, "BB" at x=24 (16+8)
    assert_eq!(fragments[0].text, "AA");
    assert_eq!(fragments[0].x, 0.0);
    assert_eq!(fragments[0].y, 0.0);

    assert_eq!(fragments[1].text, "BB");
    assert_eq!(fragments[1].x, 24.0);
    assert_eq!(fragments[1].y, 0.0);

    // Line 2: "CC" wraps to y=16 (font_size)
    assert_eq!(fragments[2].text, "CC");
    assert_eq!(fragments[2].x, 0.0);
    assert_eq!(fragments[2].y, 16.0);
}

#[test]
fn test_paragraph_align_left_float_wraps_then_releases_width() {
    let float_attrs = Attrs {
        align_x: Some(AlignX::Left),
        width: Some(Length::Px(24.0)),
        height: Some(Length::Px(40.0)),
        ..Attrs::default()
    };

    let (mut tree, para_id, child_ids) = build_paragraph(
        fixed_width_attrs(80.0),
        vec![
            ("float", ElementKind::El, float_attrs),
            (
                "t",
                ElementKind::Text,
                text_attrs("AA BB CC DD EE FF GG HH"),
            ),
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let float_frame = tree.get(&child_ids[0]).unwrap().layout.frame.unwrap();
    assert_eq!(float_frame.x, 0.0);
    assert_eq!(float_frame.y, 0.0);
    assert_eq!(float_frame.width, 24.0);
    assert_eq!(float_frame.height, 40.0);

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert!(!fragments.is_empty());

    let first_fragment = &fragments[0];
    assert_eq!(first_fragment.text, "AA");
    assert_eq!(first_fragment.x, 24.0);
    assert_eq!(first_fragment.y, 0.0);

    let released = fragments
        .iter()
        .find(|fragment| fragment.text == "GG")
        .expect("expected GG fragment after float expires");
    assert_eq!(released.x, 0.0);
    assert!(released.y >= 40.0);
}

#[test]
fn test_text_column_non_paragraph_child_clears_below_active_floats() {
    let mut tree = ElementTree::new();

    let text_col_attrs = Attrs {
        width: Some(Length::Px(80.0)),
        spacing_y: Some(8.0),
        ..Attrs::default()
    };
    let mut text_col = make_element("text_col", ElementKind::TextColumn, text_col_attrs);

    let float_attrs = Attrs {
        align_x: Some(AlignX::Left),
        width: Some(Length::Px(24.0)),
        height: Some(Length::Px(40.0)),
        ..Attrs::default()
    };
    let float_el = make_element("float", ElementKind::El, float_attrs);

    let mut para = make_element("para", ElementKind::Paragraph, fill_width_attrs());

    let para_text = make_element("para_text", ElementKind::Text, text_attrs("AA"));

    let below_block = make_element("below", ElementKind::El, fill_width_box_attrs(10.0));

    let text_col_id = text_col.id;
    let float_id = float_el.id;
    let para_id = para.id;
    let para_text_id = para_text.id;
    let below_id = below_block.id;

    para.children = vec![para_text_id];
    text_col.children = vec![float_id, para_id, below_id];

    tree.set_root_id(text_col_id);
    tree.insert(text_col);
    tree.insert(float_el);
    tree.insert(para);
    tree.insert(para_text);
    tree.insert(below_block);

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let float_frame = tree.get(&float_id).unwrap().layout.frame.unwrap();
    assert_eq!(float_frame.y, 0.0);
    assert_eq!(float_frame.height, 40.0);

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments[0].x, 24.0);
    assert_eq!(fragments[0].y, 8.0);

    let below_frame = tree.get(&below_id).unwrap().layout.frame.unwrap();
    assert_eq!(below_frame.y, 40.0);

    let text_col_frame = tree.get(&text_col_id).unwrap().layout.frame.unwrap();
    assert_eq!(text_col_frame.content_height, 50.0);
}

#[test]
fn test_paragraph_multiple_text_children() {
    // Two text children flow inline
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(200.0),
        vec![
            ("t1", ElementKind::Text, text_attrs("Hello ")),
            ("t2", ElementKind::Text, text_attrs("World")),
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    // "Hello " -> word "Hello", trailing space
    // "World" -> word "World"
    assert_eq!(fragments.len(), 2);
    assert_eq!(fragments[0].text, "Hello");
    assert_eq!(fragments[1].text, "World");
    // "Hello" = 40px, + trailing space 8px = cursor at 48
    assert_eq!(fragments[1].x, 48.0);
}

#[test]
fn test_paragraph_line_spacing() {
    // "AA BB" with 40px container -> wraps
    // spacing_y = 5
    let (mut tree, para_id, _) = build_paragraph(
        {
            Attrs {
                width: Some(Length::Px(20.0)),
                spacing: Some(5.0),
                ..Attrs::default()
            }
        },
        vec![("t", ElementKind::Text, text_attrs("AA BB"))],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 2);

    // Line 1: "AA" at y=0
    assert_eq!(fragments[0].y, 0.0);
    // Line 2: "BB" at y = 16 (line height) + 5 (spacing) = 21
    assert_eq!(fragments[1].y, 21.0);
}

#[test]
fn test_paragraph_expands_height() {
    // Paragraph has no explicit height; wrapping should expand it
    // "AA BB" in 20px container -> 2 lines of 16px each
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(20.0),
        vec![("t", ElementKind::Text, text_attrs("AA BB"))],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let frame = para.layout.frame.unwrap();
    // 2 lines * 16px = 32px
    assert_eq!(frame.height, 32.0);
}

#[test]
fn test_paragraph_with_padding() {
    // Paragraph with padding, text should be offset
    let (mut tree, para_id, _) = build_paragraph(
        {
            Attrs {
                width: Some(Length::Px(200.0)),
                padding: Some(Padding::Uniform(10.0)),
                ..Attrs::default()
            }
        },
        vec![("t", ElementKind::Text, text_attrs("Hi"))],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 1);
    // Fragment at content_x = 0 + 10 (padding_left)
    assert_eq!(fragments[0].x, 10.0);
    assert_eq!(fragments[0].y, 10.0);
}

#[test]
fn test_paragraph_el_wrapped_text() {
    // el([Font.bold()], text("Bold")) should participate in paragraph flow
    let el_attrs = Attrs {
        font_weight: Some(FontWeight("bold".to_string())),
        ..Attrs::default()
    };

    let mut el_child = make_element("el_child", ElementKind::El, el_attrs);
    let text_child = make_element("el_text", ElementKind::Text, text_attrs("Bold"));
    let text_child_id = text_child.id;
    el_child.children = vec![text_child_id];

    let mut tree = ElementTree::new();
    let para_attrs = fixed_width_attrs(200.0);
    let mut para = make_element("para", ElementKind::Paragraph, para_attrs);
    let para_id = para.id;
    let el_id = el_child.id;

    // Also add a direct text child
    let plain_text = make_element("plain", ElementKind::Text, text_attrs("Hi "));
    let plain_id = plain_text.id;

    para.children = vec![plain_id, el_id];
    tree.set_root_id(para_id);
    tree.insert(para);
    tree.insert(plain_text);
    tree.insert(el_child);
    tree.insert(text_child);

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 2);
    assert_eq!(fragments[0].text, "Hi");
    assert_eq!(fragments[1].text, "Bold");
    // "Hi" trailing space makes cursor at 16+8=24
    assert_eq!(fragments[1].x, 24.0);
    // Bold child should inherit weight 700
    assert_eq!(fragments[1].weight, 700);
}

#[test]
fn test_paragraph_skips_non_text_children() {
    // Non-text, non-el children (e.g., Row) should be silently skipped
    let row_attrs = fixed_box_attrs(50.0, 20.0);

    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(200.0),
        vec![
            ("t1", ElementKind::Text, text_attrs("Hi")),
            ("r", ElementKind::Row, row_attrs),
            ("t2", ElementKind::Text, text_attrs("There")),
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    // Row child should be skipped, only "Hi" and "There"
    assert_eq!(fragments.len(), 2);
    assert_eq!(fragments[0].text, "Hi");
    assert_eq!(fragments[1].text, "There");
}

#[test]
fn test_paragraph_empty_text_skipped() {
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(200.0),
        vec![
            ("t1", ElementKind::Text, text_attrs("")),
            ("t2", ElementKind::Text, text_attrs("Hello")),
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 1);
    assert_eq!(fragments[0].text, "Hello");
    assert_eq!(fragments[0].x, 0.0);
}

#[test]
fn test_paragraph_no_children() {
    let (mut tree, para_id, _) = build_paragraph(fixed_width_attrs(200.0), vec![]);

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert!(fragments.is_empty());
}

#[test]
fn test_paragraph_inherits_font_context() {
    // Paragraph sets font_size=20, child text has no font_size -> inherits 20
    let (mut tree, para_id, _) = build_paragraph(
        {
            Attrs {
                width: Some(Length::Px(200.0)),
                font_size: Some(20.0),
                ..Attrs::default()
            }
        },
        vec![("t", ElementKind::Text, {
            // No font_size set -> should inherit from paragraph
            Attrs {
                content: Some("Hi".to_string()),
                ..Attrs::default()
            }
        })],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 1);
    assert_eq!(fragments[0].font_size, 20.0);
}

#[test]
fn test_paragraph_intrinsic_width_is_sum_of_children() {
    // Without explicit width, paragraph intrinsic = sum of child widths
    let (mut tree, para_id, _) = build_paragraph(
        Attrs::default(),
        vec![
            ("t1", ElementKind::Text, text_attrs("AA")),   // 16px
            ("t2", ElementKind::Text, text_attrs("BBBB")), // 32px
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let frame = para.layout.frame.unwrap();
    // 16 + 32 = 48, constrained to 800 but intrinsic should be 48
    assert_eq!(frame.width, 48.0);
}

#[test]
fn test_paragraph_fragment_colors_from_children() {
    // Test that font_color from a child text element is used in fragment
    let child_attrs = Attrs {
        content: Some("Red".to_string()),
        font_size: Some(16.0),
        font_color: Some(Color::Rgb { r: 255, g: 0, b: 0 }),
        ..Attrs::default()
    };

    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(200.0),
        vec![("t", ElementKind::Text, child_attrs)],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 1);
    assert_eq!(fragments[0].color, 0xFF0000FF);
}

#[test]
fn test_paragraph_fragment_defaults_to_black() {
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(200.0),
        vec![("t", ElementKind::Text, text_attrs("Default"))],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 1);
    assert_eq!(fragments[0].color, 0x000000FF);
}

#[test]
fn test_paragraph_inside_el_shifts_fragments() {
    // An el with padding=12 containing a paragraph with text.
    // The paragraph fragments should be offset by the parent's padding.
    let mut tree = ElementTree::new();

    // Parent el with explicit size and padding
    let parent_attrs = Attrs {
        width: Some(Length::Px(400.0)),
        height: Some(Length::Px(200.0)),
        padding: Some(Padding::Uniform(12.0)),
        ..Attrs::default()
    };

    let mut parent_el = make_element("parent", ElementKind::El, parent_attrs);
    let parent_id = parent_el.id;

    // Paragraph child
    let para_attrs = fill_width_attrs();
    let mut para = make_element("para", ElementKind::Paragraph, para_attrs);
    let para_id = para.id;

    // Text child of paragraph
    let text_child = make_element("t", ElementKind::Text, text_attrs("Hello world"));
    let text_id = text_child.id;

    // Wire up children
    para.children = vec![text_id];
    parent_el.children = vec![para_id];

    tree.set_root_id(parent_id);
    tree.insert(text_child);
    tree.insert(para);
    tree.insert(parent_el);

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para_el = tree.get(&para_id).unwrap();
    let para_frame = para_el.layout.frame.unwrap();
    // Paragraph frame should be at (12, 12) due to parent padding
    assert_eq!(para_frame.x, 12.0);
    assert_eq!(para_frame.y, 12.0);

    let fragments = para_el.layout.paragraph_fragments.as_ref().unwrap();
    assert!(!fragments.is_empty(), "paragraph should have fragments");
    // Fragment positions should also be offset by the parent padding
    assert_eq!(fragments[0].x, 12.0);
    assert_eq!(fragments[0].y, 12.0);
    assert_eq!(fragments[0].text, "Hello");
}

#[test]
fn test_paragraph_wraps_to_parent_constraint() {
    // A paragraph with NO explicit width inside an el with width=100px.
    // MockTextMeasurer: each char = 8px, space = 8px
    // "AA BB CC DD" -> "AA" (16) + " " (8) + "BB" (16) + " " (8) + "CC" (16) + " " (8) + "DD" (16) = 88px
    // But words must wrap within 100px parent constraint.
    // Line 1: "AA" (16) + space (8) + "BB" (16) + space (8) + "CC" (16) = 64, + space (8) + "DD" (16) = 88 fits in 100
    // Actually let's use a narrower parent: 50px
    // Line 1: "AA" (16) + space (8) + "BB" (16) = 40, fits in 50
    // + space (8) + "CC" (16) = 64 > 50, wraps
    // Line 2: "CC" (16) + space (8) + "DD" (16) = 40, fits in 50
    let mut tree = ElementTree::new();

    let parent_attrs = fixed_width_attrs(50.0);

    let mut parent_el = make_element("parent", ElementKind::El, parent_attrs);
    let parent_id = parent_el.id;

    // Paragraph with NO explicit width
    let para_attrs = Attrs::default();
    let mut para = make_element("para", ElementKind::Paragraph, para_attrs);
    let para_id = para.id;

    let text_child = make_element("t", ElementKind::Text, text_attrs("AA BB CC DD"));
    let text_id = text_child.id;

    para.children = vec![text_id];
    parent_el.children = vec![para_id];

    tree.set_root_id(parent_id);
    tree.insert(text_child);
    tree.insert(para);
    tree.insert(parent_el);

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para_el = tree.get(&para_id).unwrap();
    let fragments = para_el.layout.paragraph_fragments.as_ref().unwrap();

    // Should wrap into 2 lines, not be a single line
    assert!(
        fragments.len() >= 3,
        "paragraph should wrap text into multiple lines, got {} fragments",
        fragments.len()
    );

    // Line 1 fragments should be at y=0
    assert_eq!(fragments[0].y, 0.0);
    assert_eq!(fragments[1].y, 0.0);
    // At least one fragment should be on line 2 (y > 0)
    let has_second_line = fragments.iter().any(|f| f.y > 0.0);
    assert!(
        has_second_line,
        "paragraph text should wrap to a second line"
    );
}

#[test]
fn test_paragraph_preserves_leading_space_between_nodes() {
    // Three text children: "Hello", " World", " End"
    // Leading spaces on " World" and " End" must be preserved.
    // MockTextMeasurer: each char = 8px, space = 8px
    // "Hello" = 40px
    // " World" -> leading space (8) + "World" (40) -> cursor at 88
    // " End" -> leading space (8) + "End" (24) -> cursor at 120
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(400.0),
        vec![
            ("t1", ElementKind::Text, text_attrs("Hello")),
            ("t2", ElementKind::Text, text_attrs(" World")),
            ("t3", ElementKind::Text, text_attrs(" End")),
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para.layout.paragraph_fragments.as_ref().unwrap();
    assert_eq!(fragments.len(), 3);
    assert_eq!(fragments[0].text, "Hello");
    assert_eq!(fragments[0].x, 0.0);
    // "Hello" = 40px, + leading space 8px = 48
    assert_eq!(fragments[1].text, "World");
    assert_eq!(fragments[1].x, 48.0);
    // "World" = 40px, cursor at 88, + leading space 8px = 96
    assert_eq!(fragments[2].text, "End");
    assert_eq!(fragments[2].x, 96.0);
}

#[test]
fn test_paragraph_left_and_right_floats_constrain_first_line_bounds() {
    let (mut tree, para_id, _) = build_paragraph(
        fixed_width_attrs(100.0),
        vec![
            ("left_float", ElementKind::El, {
                Attrs {
                    width: Some(Length::Px(20.0)),
                    height: Some(Length::Px(20.0)),
                    align_x: Some(AlignX::Left),
                    ..Attrs::default()
                }
            }),
            ("right_float", ElementKind::El, {
                Attrs {
                    width: Some(Length::Px(20.0)),
                    height: Some(Length::Px(20.0)),
                    align_x: Some(AlignX::Right),
                    ..Attrs::default()
                }
            }),
            ("text", ElementKind::Text, text_attrs("AAAA BBBB CCCC DDDD")),
        ],
    );

    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );

    let para = tree.get(&para_id).unwrap();
    let fragments = para
        .layout
        .paragraph_fragments
        .as_ref()
        .expect("paragraph fragments should exist");
    assert!(!fragments.is_empty(), "expected paragraph fragments");

    // First line should be constrained to x range [20, 80] by left+right floats.
    let first_line_y = fragments[0].y;
    let first_line: Vec<_> = fragments
        .iter()
        .filter(|frag| (frag.y - first_line_y).abs() < 0.001)
        .collect();
    assert!(!first_line.is_empty(), "expected first-line fragments");

    for frag in first_line {
        let word_w = frag.text.len() as f32 * 8.0;
        assert!(
            frag.x >= 20.0,
            "first-line fragment starts before left float bound: x={} text={} ",
            frag.x,
            frag.text
        );
        assert!(
            frag.x + word_w <= 80.0,
            "first-line fragment overflows right float bound: x={} w={} text={} ",
            frag.x,
            word_w,
            frag.text
        );
    }
}

#[test]
fn inline_border_insets_wrap_and_align_the_outer_line_box() {
    let (mut tree, id, children) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Center),
            ..fixed_width_attrs(50.0)
        },
        vec![(
            "inline",
            ElementKind::El,
            Attrs {
                border_width: Some(BorderWidth::Uniform(2.0)),
                ..Attrs::default()
            },
        )],
    );
    let text = make_element("inline_text", ElementKind::Text, text_attrs("AA BB CC"));
    let text_id = text.id;
    tree.insert(text);
    tree.set_children(&children[0], vec![text_id]).unwrap();
    layout_tree(
        &mut tree,
        Constraint::new(800.0, 600.0),
        1.0,
        &MockTextMeasurer,
    );
    assert_eq!(
        paragraph_positions(&tree, id),
        vec![(5.0, 2.0), (29.0, 2.0), (17.0, 22.0)]
    );
    assert_eq!(tree.get(&id).unwrap().layout.frame.unwrap().height, 40.0);
}

fn inline_paragraph(attrs: Attrs, width: f64, content: &str) -> (ElementTree, NodeId, NodeId) {
    let (mut tree, paragraph, children) = build_paragraph(
        Attrs {
            align_x: Some(AlignX::Center),
            ..fixed_width_attrs(width)
        },
        vec![("wrapper", ElementKind::El, attrs)],
    );
    let text = make_element("inline_body", ElementKind::Text, text_attrs(content));
    let text_id = text.id;
    tree.insert(text);
    tree.set_children(&children[0], vec![text_id]).unwrap();
    (tree, paragraph, children[0])
}

#[test]
fn inline_boxes_clone_insets_without_per_word_seams() {
    let (mut tree, paragraph, owner) = inline_paragraph(
        Attrs {
            border_width: Some(BorderWidth::Sides {
                top: 1.0,
                right: 2.0,
                bottom: 3.0,
                left: 4.0,
            }),
            padding: Some(Padding::Uniform(1.0)),
            ..Attrs::default()
        },
        50.0,
        "AA BB CC",
    );
    layout_tree(
        &mut tree,
        Constraint::new(200.0, 200.0),
        1.0,
        &MockTextMeasurer,
    );
    let boxes = &tree.get(&paragraph).unwrap().layout.paragraph_boxes;
    assert_eq!(boxes.len(), 2);
    assert_eq!(boxes[0].owner, owner);
    assert_eq!(boxes[0].text_range, 0..2);
    assert_eq!(boxes[1].text_range, 2..3);
    assert_eq!(
        (
            boxes[0].frame.x,
            boxes[0].frame.width,
            boxes[0].frame.height
        ),
        (1.0, 48.0, 22.0)
    );
    assert_eq!(
        (boxes[1].frame.x, boxes[1].frame.y, boxes[1].frame.width),
        (13.0, 22.0, 24.0)
    );
    assert_eq!(
        paragraph_positions(&tree, paragraph),
        vec![(6.0, 2.0), (30.0, 2.0), (18.0, 24.0)]
    );
}

#[test]
fn inline_empty_and_oversized_boxes_terminate_and_keep_minimum_insets() {
    for (content, expected_width, expected_height) in
        [("", 8.0, 8.0), ("   ", 8.0, 8.0), ("AAAAAAA", 64.0, 24.0)]
    {
        let (mut tree, paragraph, _) = inline_paragraph(
            Attrs {
                border_width: Some(BorderWidth::Uniform(4.0)),
                ..Attrs::default()
            },
            20.0,
            content,
        );
        layout_tree(
            &mut tree,
            Constraint::new(200.0, 200.0),
            1.0,
            &MockTextMeasurer,
        );
        let boxes = &tree.get(&paragraph).unwrap().layout.paragraph_boxes;
        assert_eq!(boxes.len(), 1);
        assert_eq!(boxes[0].frame.width, expected_width);
        assert_eq!(boxes[0].frame.height, expected_height);
        assert!(boxes[0].frame.x >= 0.0);
    }
}

#[test]
fn inline_shadow_geometry_is_layout_neutral_and_retained_even_before_paint() {
    use crate::tree::attrs::{BoxShadow, Color};
    let (mut tree, paragraph, owner) = inline_paragraph(Attrs::default(), 50.0, "AA BB CC");
    let measurer = CountingTextMeasurer::default();
    layout_tree(&mut tree, Constraint::new(200.0, 200.0), 1.0, &measurer);
    let calls = measurer.total_calls();
    let positions = paragraph_positions(&tree, paragraph);
    let boxes = tree.get(&paragraph).unwrap().layout.paragraph_boxes.clone();
    assert_eq!(boxes.len(), 2);
    tree.get_mut(&owner).unwrap().spec.declared.box_shadows = Some(vec![BoxShadow {
        offset_x: -5.0,
        offset_y: 7.0,
        blur: 20.0,
        size: 10.0,
        color: Color::Named("blue".into()),
        inset: false,
    }]);
    tree.mark_measure_dirty_for_invalidation(
        &owner,
        crate::tree::invalidation::TreeInvalidation::Paint,
    );
    layout_tree(&mut tree, Constraint::new(200.0, 200.0), 1.0, &measurer);
    assert_eq!(measurer.total_calls(), calls);
    assert_eq!(paragraph_positions(&tree, paragraph), positions);
    assert_eq!(
        tree.get(&paragraph)
            .unwrap()
            .layout
            .paragraph_boxes
            .iter()
            .map(|b| b.frame)
            .collect::<Vec<_>>(),
        boxes.iter().map(|b| b.frame).collect::<Vec<_>>()
    );
}

#[test]
fn inline_borders_use_identical_local_and_shared_float_exclusions() {
    let build = |shared| {
        let (mut tree, paragraph, _) = inline_paragraph(
            Attrs {
                border_width: Some(BorderWidth::Uniform(2.0)),
                ..Attrs::default()
            },
            80.0,
            "AA BB CC DD",
        );
        let float = make_element(
            "inline_float",
            ElementKind::El,
            Attrs {
                align_x: Some(AlignX::Left),
                ..fixed_box_attrs(24.0, 20.0)
            },
        );
        let float_id = float.id;
        tree.insert(float);
        if shared {
            let root = make_element(
                "inline_column",
                ElementKind::TextColumn,
                fixed_width_attrs(80.0),
            );
            let root_id = root.id;
            tree.insert(root);
            tree.set_root_id(root_id);
            tree.set_children(&root_id, vec![float_id, paragraph])
                .unwrap();
        } else {
            let children = std::iter::once(float_id)
                .chain(tree.child_ids(&paragraph))
                .collect();
            tree.set_children(&paragraph, children).unwrap();
        }
        layout_tree(
            &mut tree,
            Constraint::new(200.0, 200.0),
            1.0,
            &MockTextMeasurer,
        );
        let positions = paragraph_positions(&tree, paragraph);
        assert!(positions[0].0 >= 24.0);
        assert!(positions[2].0 < 24.0);
        positions
    };
    assert_eq!(build(false), build(true));
}

#[test]
fn inline_trailing_space_counts_closing_border_once_and_keeps_completed_height() {
    let (mut tree, paragraph, _) = inline_paragraph(
        Attrs {
            border_width: Some(BorderWidth::Uniform(2.0)),
            ..Attrs::default()
        },
        29.0,
        "AA ",
    );
    layout_tree(
        &mut tree,
        Constraint::new(200.0, 200.0),
        1.0,
        &MockTextMeasurer,
    );
    let layout = &tree.get(&paragraph).unwrap().layout;
    assert_eq!(layout.paragraph_boxes[0].frame.width, 28.0);
    assert_eq!(layout.frame.unwrap().height, 20.0);
    for wrapped in [false, true] {
        let (mut tree, paragraph) = if wrapped {
            let (tree, paragraph, _) = inline_paragraph(
                Attrs {
                    border_width: Some(BorderWidth::Uniform(2.0)),
                    ..Attrs::default()
                },
                20.0,
                "AA ",
            );
            (tree, paragraph)
        } else {
            let (tree, paragraph, _) = build_paragraph(
                fixed_width_attrs(20.0),
                vec![("text", ElementKind::Text, text_attrs("AA "))],
            );
            (tree, paragraph)
        };
        layout_tree(
            &mut tree,
            Constraint::new(200.0, 200.0),
            1.0,
            &MockTextMeasurer,
        );
        assert_eq!(
            tree.get(&paragraph).unwrap().layout.frame.unwrap().height,
            if wrapped { 20.0 } else { 16.0 }
        );
    }
}
